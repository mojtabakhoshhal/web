import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, patch
from openpyxl import Workbook, load_workbook
from scraper.normalize import money, markup, canonical_url, metric, metric_range, review_summary, source_hash
from scraper.extract import parse_product, size_table, listing_urls
from scraper.digikala import wire_price, export_template, Seller

class NormalizationTests(unittest.TestCase):
    def test_persian_money_and_explicit_units(self):
        self.assertEqual(money('۱٬۲۳۰٬۰۰۰ تومان','IRT'),1230000)
        self.assertEqual(money('۱۲٬۳۰۰٬۰۰۰','IRR'),1230000)
        for value,unit in [('1200','USD'),('1001','IRR'),('۱.۲ میلیون','IRT')]:
            with self.assertRaises(ValueError): money(value,unit)
    def test_markup_matches_server_integer_policy(self):
        self.assertEqual(markup(1_000_000),1_350_000)
        self.assertEqual(markup(1_010_000),1_363_500)
    def test_canonical_url_preserves_actual_variant_parameters(self):
        self.assertEqual(canonical_url('https://verna.ir/product/1/?utm_source=a&size=L&color=black#x'),'https://verna.ir/product/1/?color=black&size=L')
    def test_metric_width_and_inches_are_converted_only_explicitly(self):
        self.assertEqual(metric('۵۲','cm',True),104)
        self.assertEqual(metric('20','in'),50.8)
        with self.assertRaises(ValueError):metric('48-50')
    def test_metric_range_is_preserved_instead_of_collapsed(self):
        self.assertEqual(metric_range('۵۲ تا ۵۶','cm',True),{'min':104,'max':112})
    def test_photo_color_changes_do_not_create_duplicate_source_identity(self):
        self.assertEqual(source_hash('verna','real-sku','#112233'),source_hash('verna','real-sku','#334455'))
    def test_review_summary_does_not_invent_verified_buyer_statistics(self):
        rows=[{'reviewBody':f'سایز مناسب بود {i}'} for i in range(5)]+[{'reviewBody':'سایز مناسب نبود و کوچک بود'}]
        result=review_summary(rows)
        self.assertEqual(result['fit_mentions'],6);self.assertEqual(result['positive_fit_mentions'],5)
        self.assertNotIn('94%',result['summary']);self.assertIn('نمونه',result['summary'])
    def test_size_table_respects_flat_width(self):
        html='<table><tr><th>سایز</th><th>عرض سینه</th><th>دور کمر</th></tr><tr><td>L</td><td>۵۶</td><td>۱۰۶</td></tr></table>'
        self.assertEqual(size_table(html,'cm')['L'],{'chest':112.0,'waist':106.0})
        self.assertEqual(size_table(html,None),{})
    def product(self):
        return {'@type':'Product','name':'هودی مردانه','sku':'HOOD-1','image':['https://cdn.verna.ir/p.jpg'],'hasVariant':[{'sku':'HOOD-L','size':'L','offers':{'price':'1000000','priceCurrency':'IRT','availability':'https://schema.org/InStock'}}]}
    def test_instock_boolean_never_becomes_fake_quantity(self):
        p=parse_product(self.product(),'', 'https://verna.ir/product/1/',{'source':'verna'},'#222222')
        self.assertIsNone(p['variants'][0]['quantity']);self.assertIsNone(p['bnpl'])
    def test_explicit_outofstock_overrides_a_stale_inventory_level(self):
        d=self.product();d['hasVariant'][0]['offers'].update(availability='https://schema.org/OutOfStock',inventoryLevel={'value':7})
        p=parse_product(d,'','https://verna.ir/product/1/',{'source':'verna'},'#222222')
        self.assertEqual(p['variants'][0]['quantity'],0)
    def test_actual_variant_stock_is_preserved(self):
        d=self.product();d['hasVariant'][0]['offers']['inventoryLevel']={'value':2}
        p=parse_product(d,'','https://verna.ir/product/1/',{'source':'verna'},'#222222')
        self.assertEqual(p['variants'][0]['quantity'],2)
    def test_aggregate_low_price_is_not_a_concrete_offer(self):
        d={'@type':'Product','name':'هودی مردانه','offers':{'@type':'AggregateOffer','lowPrice':1000,'priceCurrency':'IRT'}}
        with self.assertRaises(ValueError):parse_product(d,'','https://verna.ir/product/1/',{'source':'verna'},'#222222')
    def test_listing_links_cannot_escape_source_allowlist(self):
        html='<script type="application/ld+json">'+json.dumps({'@type':'ItemList','itemListElement':[{'@type':'ListItem','item':{'url':'https://verna.ir/product/1/'}},{'@type':'ListItem','item':{'url':'https://evil.test/'}}]})+'</script>'
        self.assertEqual(listing_urls(html,'https://verna.ir/',{'verna.ir'}),['https://verna.ir/product/1/'])
    def test_seller_price_unit_must_be_verified(self):
        self.assertEqual(wire_price(1200000,'IRR'),12000000)
        with self.assertRaises(ValueError):wire_price(1200000,'')
    def test_real_workbook_template_and_unmapped_columns_are_preserved(self):
        with tempfile.TemporaryDirectory() as t:
            source=Path(t)/'template.xlsx';output=Path(t)/'filled.xlsx';w=Workbook();w.active.append(['شناسه','قیمت ریال','موجودی','متن ثابت']);w.active['D2']='keep';w.save(source)
            export_template([{'variant_id':42,'selling_price_toman':1200,'stock':2}],str(source),str(output),None,{'header_row':1,'variant_id':'شناسه','price':'قیمت ریال','stock':'موجودی','price_currency':'IRR'})
            sheet=load_workbook(output).active;self.assertEqual(sheet['B2'].value,12000);self.assertEqual(sheet['D2'].value,'keep')

class SellerTests(unittest.IsolatedAsyncioTestCase):
    async def test_price_update_failure_keeps_seller_stock_closed(self):
        with patch.dict('os.environ',{'DIGIKALA_TOKEN':'unit-test-only'},clear=True):seller=Seller()
        seller.request=AsyncMock(side_effect=[{'status':'ok'},ValueError('price rejected')])
        try:
            with self.assertRaises(ValueError):await seller.update({'variant_id':123,'stock':3,'selling_price_toman':1000000,'api_currency':'IRR','observed_at':'2099-01-01T00:00:00+00:00'})
            self.assertEqual(seller.request.call_args_list[0].args[2],{'seller_stock':0})
            self.assertEqual(seller.request.await_count,2)
        finally:await seller.close()

if __name__=='__main__':unittest.main()

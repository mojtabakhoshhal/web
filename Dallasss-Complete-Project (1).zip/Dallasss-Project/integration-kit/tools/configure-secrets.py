"""Run locally on a private wp-config.php copy. Secrets are never command-line arguments."""
import getpass
import os
from pathlib import Path
import re
import tempfile

def php_string(value: str) -> str:
    return "'" + value.replace('\\', '\\\\').replace("'", "\\'") + "'"

def main():
    path = Path(input('Absolute path to the private wp-config.php copy: ').strip()).expanduser().resolve()
    if path.name != 'wp-config.php' or not path.is_file(): raise SystemExit('Select the actual wp-config.php file.')
    text = path.read_text(encoding='utf-8')
    token = getpass.getpass('Telegram bot token (hidden): ').strip()
    chat = input('Telegram admin chat ID: ').strip()
    if not re.fullmatch(r'\d+:[A-Za-z0-9_-]{25,}', token): raise SystemExit('Token format is invalid.')
    if not re.fullmatch(r'-?\d{4,20}', chat): raise SystemExit('Chat ID format is invalid.')
    for name,value in [('DALLASSS_TELEGRAM_BOT_TOKEN',token),('DALLASSS_TELEGRAM_CHAT_ID',chat)]:
        pattern = r"^[ \t]*define\(\s*['\"]"+name+r"['\"]\s*,[^\n]+$"
        text,count=re.subn(pattern,lambda _: 'define('+php_string(name)+', '+php_string(value)+');',text,flags=re.M)
        if count != 1: raise SystemExit('Merge hosting/wp-config.fragment.php first; each Dallasss constant must exist exactly once.')
    with tempfile.NamedTemporaryFile('w',encoding='utf-8',dir=path.parent,delete=False) as temp:
        os.chmod(temp.name,0o600);temp.write(text);temporary=Path(temp.name)
    temporary.replace(path)
    print('Configuration updated. Upload only to your own WordPress root; never add this file to Git.')

if __name__=='__main__': main()

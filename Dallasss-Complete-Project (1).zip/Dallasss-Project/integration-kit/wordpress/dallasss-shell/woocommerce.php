<?php get_header(); ?><main class="dallasss-wp-content"><?php woocommerce_content(); ?></main><?php get_footer(); ?>

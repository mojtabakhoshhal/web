<footer style="padding:30px 6%;border-top:1px solid #ffffff20;color:#9ca3af">DALLASSS — استایل تو، قانون تو.</footer><?php wp_footer(); ?></body></html>

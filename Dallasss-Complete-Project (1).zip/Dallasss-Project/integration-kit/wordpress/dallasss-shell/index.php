<!doctype html>
<html <?php language_attributes(); ?>><head><meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width,initial-scale=1"><?php wp_head(); ?></head><body <?php body_class(); ?>><?php wp_body_open(); ?>
<?php while (have_posts()) : the_post(); ?>
<?php if (has_shortcode(get_the_content(), 'dallasss_storefront')) : the_content(); ?>
<?php else : ?><main class="dallasss-wp-content"><a href="<?php echo esc_url(home_url('/')); ?>">← DALLASSS</a><?php the_content(); ?></main><?php endif; ?>
<?php endwhile; ?>
<?php wp_footer(); ?></body></html>

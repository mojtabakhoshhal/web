<?php
add_action('after_setup_theme', function () { add_theme_support('title-tag');add_theme_support('woocommerce'); });
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('dallasss-base', plugins_url('dallasss-core/storefront/assets/style.css'), [], '1.0.0');
    wp_enqueue_style('dallasss-shell', get_stylesheet_uri(), ['dallasss-base'], '1.0.0');
});

<?php
/**
 * Plugin Name: Dallasss Commerce Core
 * Description: Bounded supplier imports, remote images, freshness protection, feeds and fulfillment for WooCommerce.
 * Version: 1.0.0
 * Requires PHP: 8.2
 * Requires Plugins: woocommerce
 * License: GPL-2.0-or-later
 */
namespace Dallasss;
defined('ABSPATH') || exit;
define('DALLASSS_CORE_FILE', __FILE__);
define('DALLASSS_CORE_DIR', __DIR__);
require_once __DIR__ . '/includes/schema.php';
require_once __DIR__ . '/includes/settings.php';
register_activation_hook(__FILE__, __NAMESPACE__ . '\\activate');
register_deactivation_hook(__FILE__, function () { wp_clear_scheduled_hook('dallasss_maintenance'); });
add_action('before_woocommerce_init', function () {
    if (class_exists('Automattic\\WooCommerce\\Utilities\\FeaturesUtil')) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', DALLASSS_CORE_FILE, true);
    }
});
add_action('plugins_loaded', function () {
    if (!class_exists('WooCommerce')) { return; }
    foreach (['media', 'import', 'api', 'sync-admin', 'orders', 'payment', 'storefront'] as $module) {
        require_once __DIR__ . '/includes/' . $module . '.php';
    }
});

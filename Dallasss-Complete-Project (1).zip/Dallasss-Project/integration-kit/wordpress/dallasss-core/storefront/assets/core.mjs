export const toman = value => new Intl.NumberFormat('fa-IR').format(Math.round(value));
export const markup = (source, percent = 35, buffer = 0, rounding = 1) => Math.ceil((source * (100 + percent) / 100 + buffer) / rounding) * rounding;
export const escapeHTML = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function colorHarmony(a, b) {
  const rgb = h => h.replace('#','').match(/.{2}/g).map(x => parseInt(x,16) / 255);
  const hue = h => {const c=rgb(h), max=Math.max(...c), min=Math.min(...c), d=max-min;if(d<.12)return null;let x=max===c[0]?(c[1]-c[2])/d:max===c[1]?(c[2]-c[0])/d+2:(c[0]-c[1])/d+4;return (x*60+360)%360;};
  const x=hue(a), y=hue(b);if(x===null||y===null)return 1;
  const d=Math.min(Math.abs(x-y),360-Math.abs(x-y));return d<40||d>145 ? .95 : .45;
}
export function matchOutfit(products, anchor, budget, occasion = 'all', seed = 0) {
  const target = ['Top','Bottom','Footwear'];
  const other = target.filter(c => c !== anchor.category);
  if (!target.includes(anchor.category)) return null;
  const available = products.filter(p => p.id !== anchor.id && p.source !== anchor.source && p.stock > 0 && (occasion === 'all' || p.occasions.includes(occasion)));
  const pools = other.map(c => available.filter(p => p.category === c));
  let options=[];
  for (const a of pools[0]) for (const b of pools[1]) {
    if(a.source===b.source)continue;
    const total=anchor.price+a.price+b.price;
    if(total>budget)continue;
    const score=colorHarmony(anchor.color,a.color)+colorHarmony(anchor.color,b.color)+a.tags.filter(t=>anchor.tags.includes(t)).length*.3+b.tags.filter(t=>anchor.tags.includes(t)).length*.3;
    options.push({items:[anchor,a,b].sort((x,y)=>target.indexOf(x.category)-target.indexOf(y.category)),total,score});
  }
  options.sort((a,b)=>b.score-a.score||a.total-b.total);
  return options.length ? options[seed % Math.min(options.length,5)] : null;
}
export function recommendSize(chart, body, preference = 'regular') {
  const fields=['chest','waist','shoulder'];
  const measured = fields.filter(f => Number(body[f])>0);
  if(!measured.length||!chart.length)return null;
  const ease={slim:4,regular:8,loose:14}[preference]??8;
  const choices=chart.map(row=>{
    let score=0,heat={},compared=0,hasRange=false;
    for(const f of measured){
      const range=typeof row[f]==='object'&&row[f]!==null?row[f]:null;
      const minimum=range?Number(range.min):Number(row[f]);
      const maximum=range?Number(range.max):minimum;
      if(!Number.isFinite(minimum)||!Number.isFinite(maximum)||minimum<=0||maximum<minimum)continue;
      compared++;hasRange ||= minimum!==maximum;
      const delta=minimum-Number(body[f]);
      const ideal=f==='shoulder'?(preference==='loose'?4:2):ease;
      heat[f]=delta<(f==='shoulder'?0:3)?'snug':delta>ideal+6?'loose':'perfect';
      score+=Math.abs(delta-ideal)+(delta<0?Math.abs(delta)*5+20:0);
    }
    return {...row,score,heat,compared,hasRange};
  }).filter(row=>row.compared>0).sort((a,b)=>a.score-b.score);
  if(!choices.length)return null;
  return {...choices[0],confidence:choices[0].compared>=2&&!choices[0].hasRange?'medium':'low',available:choices[0].stock>0};
}
export function referenceBody(size) {
  return {S:{chest:90,waist:76,shoulder:43},M:{chest:96,waist:82,shoulder:45},L:{chest:102,waist:88,shoulder:47},XL:{chest:110,waist:96,shoulder:49},XXL:{chest:118,waist:104,shoulder:51}}[size];
}
export function validateCart(lines, products) {
  return lines.filter(l => {const p=products.find(p=>p.id===l.id);const size=p?.sizes?.find(s=>s.label===l.size);return p&&size&&l.quantity>0&&l.quantity<=size.stock;});
}

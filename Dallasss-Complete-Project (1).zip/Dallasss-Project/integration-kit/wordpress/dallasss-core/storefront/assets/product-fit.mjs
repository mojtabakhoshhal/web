import {recommendSize} from './core.mjs';
for(const root of document.querySelectorAll('[data-dallasss-fit]')){
 const chart=JSON.parse(root.dataset.chart);const output=root.querySelector('output');
 const update=()=>{
  const body={};let valid=true;for(const field of ['chest','waist','shoulder']){const input=root.querySelector(`[name=${field}]`);if(!input.checkValidity())valid=false;body[field]=Number(input.value);}
  if(!valid){output.textContent='اندازه‌ها را در محدودهٔ مشخص‌شده وارد کن.';return;}
  const result=recommendSize(chart,body,root.querySelector('[name=preference]').value);
  if(!result){output.textContent='جدول اندازهٔ معتبر و قابل مقایسه موجود نیست.';return;}
  output.textContent=`سایز پیشنهادی ${result.label}${result.available?'':' · فعلاً ناموجود'}؛ پیشنهاد تقریبی بر اساس جدول فروشنده`;
  const colors={perfect:'#78c6a5',snug:'#ddb76a',loose:'#719fda'};
  for(const field of ['chest','waist','shoulder'])root.querySelector(`[data-heat=${field}]`).setAttribute('fill',colors[result.heat[field]??'perfect']);
  root.querySelector('[data-male]').setAttribute('transform',`translate(80 120) scale(${Math.min(1.15,Math.max(.8,body.chest/102))} 1) translate(-80 -120)`);
 };
 for(const input of root.querySelectorAll('input,select'))input.addEventListener('input',update);update();
}

import {DEMO_PRODUCTS} from './catalog.mjs';
import {toman,escapeHTML as esc,matchOutfit,recommendSize,referenceBody,validateCart} from './core.mjs';

const config=window.DALLASSS_CONFIG??{mode:'demo',assetBase:'./assets/',bundleDiscountPercent:0};
const $=id=>document.getElementById(id);
const asset=name=>config.assetBase+name;
const img=p=>/^https:\/\//.test(p.image)?p.image:asset(p.image);
const icon=name=>`<svg aria-hidden="true"><use href="#i-${name}"/></svg>`;
const price=n=>`${toman(n)} <small>تومان</small>`;
const safeStorage={get(key,fallback){try{return JSON.parse(localStorage.getItem('dallasss:'+key))??fallback;}catch{return fallback;}},set(key,value){try{localStorage.setItem('dallasss:'+key,JSON.stringify(value));}catch{}}};
let products=config.mode==='demo'?DEMO_PRODUCTS:[];
let favorites=new Set(safeStorage.get('favorites',[]).filter(x=>Number.isSafeInteger(x)));
let cart=safeStorage.get('cart',[]);if(!Array.isArray(cart))cart=[];
let occasion='all',source='all',category='all',sort='curated',query='',favoritesOnly=false,visible=4;
let outfit=null,anchor=null,outfitSeed=0,currentProduct=null,currentSize=null,currentColor=null,fitMode='reference',fitProduct=null,photoURL=null,photoFile=null,toastTimer;
const installment=p=>p.installmentAmount;

function notify(message){$('toast').textContent=message;$('toast').classList.add('visible');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('toast').classList.remove('visible'),3800);}
function openDialog(id){const d=$(id);if(typeof d.showModal==='function'){if(!d.open)d.showModal();}else d.setAttribute('open','');}
function closeDialog(id){const d=$(id);if(typeof d.close==='function')d.close();else d.removeAttribute('open');}
async function api(path,options={}){
 const response=await fetch(config.apiBase+path,{credentials:'same-origin',...options,headers:{'Content-Type':'application/json',...(config.nonce?{'X-WP-Nonce':config.nonce}:{}),...options.headers}});
 const data=await response.json();if(!response.ok)throw new Error(data.message??'ارتباط با فروشگاه برقرار نشد');return data;
}
function filteredProducts(){
 let list=products.filter(p=>(occasion==='all'||p.occasions.includes(occasion))&&(source==='all'||p.source===source)&&(category==='all'||p.category===category)&&(!favoritesOnly||favorites.has(p.id))&&(!query||(p.title+' '+p.english+' '+p.sourceName).toLowerCase().includes(query.toLowerCase())));
 if(sort==='price-up')list.sort((a,b)=>a.price-b.price);if(sort==='price-down')list.sort((a,b)=>b.price-a.price);if(sort==='drop')list.sort((a,b)=>Number(!!b.drop)-Number(!!a.drop));return list;
}
function productCard(p,index){return `<article class="product-card" data-id="${p.id}"><div class="product-image" role="button" tabindex="0" aria-label="جزئیات ${esc(p.title)}" data-open-product="${p.id}"><img src="${esc(img(p))}" alt="${esc(p.title)}" loading="lazy"><span class="product-index">D / ${String(index+1).padStart(2,'0')}</span>${p.drop?'<span class="product-badge price-drop">↘ افت قیمت'+(p.demo?' · نمونه':' واقعی')+'</span>':p.bnpl?'<span class="product-badge">امکان خرید اقساطی</span>':''}<button class="heart-button ${favorites.has(p.id)?'saved':''}" data-favorite="${p.id}" aria-pressed="${favorites.has(p.id)}" aria-label="${favorites.has(p.id)?'حذف از':'افزودن به'} علاقه‌مندی‌ها">${icon('heart')}</button><button class="quick-add" data-to-outfit="${p.id}">+ افزودن به استایل من</button></div><div class="product-meta"><div class="product-overline"><span>${esc(p.english)}</span><span>${esc(p.sourceName)}</span></div><h3><button data-open-product="${p.id}">${esc(p.title)}</button></h3><div class="price-row"><strong>${price(p.price)}</strong>${p.oldPrice>p.price?`<del>${toman(p.oldPrice)}</del>`:''}<span class="swatches" style="margin-inline-start:auto">${p.colors.map(c=>`<i style="background:${/^#[0-9a-f]{6}$/i.test(c)?c:'#888888'}"></i>`).join('')}</span></div><p class="installment">${p.bnpl?`۴ قسطِ <b>${toman(installment(p))} تومانی</b>${p.demo?' · نمونه':''}`:`${p.fit==='Oversized'?'فیت آزاد، حال‌وهوای شهری':'یک تکهٔ ساده، انتخاب‌های بیشتر'}`}</p></div></article>`;}
function renderCatalog(){const list=filteredProducts();$('product-grid').innerHTML=list.length?list.slice(0,visible).map(productCard).join(''):`<div class="empty-state"><h3>${favoritesOnly?'کمد علاقه‌مندی‌هایت هنوز خالی است':'این انتخاب را پیدا نکردیم'}</h3><p>فیلتر دیگری را امتحان کن یا به همه انتخاب‌ها برگرد.</p><button class="button outline" data-action="clear-filters">همه انتخاب‌ها</button></div>`;$('results-count').textContent=toman(list.length);$('show-more').hidden=visible>=list.length;$('filter-count').textContent=(source!=='all'||category!=='all')?'●':'';updateCounts();}
function updateCounts(){const quantity=cart.reduce((n,l)=>n+l.quantity,0);$('cart-count').textContent=toman(quantity);$('favorite-count').textContent=toman(favorites.size);$('favorite-count').hidden=favorites.size===0;const b=document.querySelector('[data-action="favorites"]');b?.classList.toggle('favorites-active',favoritesOnly);safeStorage.set('favorites',[...favorites]);safeStorage.set('cart',cart);}
function selectOccasion(value){occasion=value;document.querySelectorAll('[data-occasion]').forEach(b=>{b.classList.toggle('selected',b.dataset.occasion===value);b.setAttribute('aria-pressed',String(b.dataset.occasion===value));});visible=4;renderCatalog();outfitSeed=0;void buildOutfit();}
function clearFilters(){occasion='all';source='all';category='all';sort='curated';query='';favoritesOnly=false;visible=4;$('source-filter').value='all';$('category-filter').value='all';$('sort-filter').value='curated';$('search-input').value='';selectOccasion('all');}
function renderDetail(){
 const p=currentProduct;if(!p)return;
 const s=p.sizes.find(s=>s.label===currentSize);
 $('product-detail').innerHTML=`<div class="product-detail-grid"><div class="detail-photo"><img src="${esc(img(p))}" alt="${esc(p.title)}"></div><div class="detail-copy"><div class="eyebrow">${esc(p.english)}</div><h2>${esc(p.title)}</h2><div class="price-row"><strong>${price(p.price)}</strong>${p.oldPrice>p.price?`<del>${toman(p.oldPrice)}</del>`:''}</div>${p.demo?'<p class="detail-demo">محصول نمایشی · قیمت، اقساط و تعداد موجودی نمونه هستند.</p>':''}<p class="detail-description">${esc(p.sourceName)} · فیت ${esc(p.fit)}<br>${p.category==='Top'?'برای یک استایل لایه‌ای، کنار دنیم و یک جفت اسنیکر قرارش بده. برای انتخاب سایز، راهنمای فیت را امتحان کن.':'تکه‌ای برای کامل کردن استایل شخصی تو. سایز موجود را انتخاب کن و به سبد یا ستت اضافه کن.'}</p><div class="detail-colors">رنگ انتخابی ${p.colors.map(c=>`<button class="${c===currentColor?'selected':''}" data-color="${esc(c)}" style="background:${/^#[0-9a-f]{6}$/i.test(c)?c:'#888888'}" aria-label="رنگ ${esc(c)}" aria-pressed="${c===currentColor}"></button>`).join('')}</div><span class="size-label">سایز خودت را انتخاب کن</span><div class="size-options" role="group" aria-label="انتخاب سایز">${p.sizes.map(s=>`<button data-size="${esc(s.label)}" class="${s.label===currentSize?'selected':''}" aria-pressed="${s.label===currentSize}" ${s.stock<=0?'disabled':''}>${esc(s.label)}</button>`).join('')}</div><p class="stock-label">${s?.stock>0?`${toman(s.stock)} عدد در سایز ${esc(s.label)}${p.demo?' · نمونه':''}`:'این سایز موجود نیست'}</p>${p.bnpl?`<p class="installment">شروع از ${toman(installment(p))} تومان در ۴ قسط${p.demo?' · نمونه':''}</p>`:''}<div class="detail-buttons"><button class="button gold" data-action="add-current" ${!s?.stock?'disabled':''}>افزودن به سبد ${icon('bag')}</button><button class="button outline" data-to-outfit="${p.id}">به مانکن استایل من اضافه کن ${icon('layers')}</button>${p.category==='Top'?`<button class="text-link" data-action="fit-current">راهنمای فیت این لباس ${icon('ruler')}</button>`:''}${p.bnpl?'<button class="text-link" data-action="affiliate-current">بررسی خرید اقساطی در فروشگاه منبع ↗</button>':''}</div><p class="review-summary">${p.reviewSummary?esc(p.reviewSummary):'دیدگاه تأییدشده‌ای برای نمایش ثبت نشده است.'}</p></div></div>`;
}
function showProduct(id){const p=products.find(p=>p.id===Number(id));if(!p)return;currentProduct=p;currentSize=p.sizes.find(s=>s.stock>0)?.label??null;currentColor=p.color;renderDetail();openDialog('product-dialog');}
function addLine(id,size,quantity=1,color=null){const p=products.find(p=>p.id===Number(id));const s=p?.sizes.find(s=>s.label===size);if(!p||!s||s.stock<=0){notify('سایز موجودی را انتخاب کن.');return false;}const current=cart.find(l=>l.id===p.id&&l.size===size&&(l.color??p.color)===(color??p.color));if((current?.quantity??0)+quantity>s.stock){notify('تعداد انتخابی از موجودی این سایز بیشتر است.');return false;}if(current)current.quantity+=quantity;else cart.push({id:p.id,size,quantity,color:color??p.color});updateCounts();return true;}
function renderCart(){
 cart=validateCart(cart,products);updateCounts();$('drawer-cart-count').textContent=toman(cart.reduce((n,l)=>n+l.quantity,0));
 if(!cart.length){$('cart-lines').innerHTML='<div class="empty-state"><h3>کمد تازه‌ات از اینجا شروع می‌شود.</h3><p>یک تکهٔ دوست‌داشتنی از رگال بردار.</p><button class="button gold" data-action="continue-shopping">دیدن منتخب‌ها</button></div>';$('cart-footer').innerHTML='';return;}
 $('cart-lines').innerHTML=cart.map((l,index)=>{const p=products.find(p=>p.id===l.id);return `<div class="cart-line"><img src="${esc(img(p))}" alt="${esc(p.title)}"><div><h3>${esc(p.title)}</h3><p>${esc(p.sourceName)} · سایز ${esc(l.size)}</p><strong>${price(p.price*l.quantity)}</strong><div class="quantity-control"><button data-quantity="${index}" data-delta="-1" aria-label="کم کردن تعداد">−</button><span>${toman(l.quantity)}</span><button data-quantity="${index}" data-delta="1" aria-label="زیاد کردن تعداد">+</button></div></div><button class="cart-remove" data-remove="${index}" aria-label="حذف ${esc(p.title)}">×</button></div>`;}).join('');
 const total=cart.reduce((n,l)=>n+products.find(p=>p.id===l.id).price*l.quantity,0);
 $('cart-footer').innerHTML=`<div class="cart-total"><span>جمع انتخاب‌ها</span><strong>${price(total)}</strong></div><button class="button gold" data-action="checkout">${config.mode==='demo'?'بررسی نهایی سبد نمونه':'ادامهٔ خرید و بررسی موجودی'} ${icon('arrow')}</button><p>${config.mode==='demo'?'نسخهٔ نمایشی است؛ سفارشی ثبت نمی‌شود و پرداختی انجام نمی‌گیرد.':'موجودی و مبلغ نهایی در مرحلهٔ پرداخت دوباره بررسی می‌شوند. هزینه ارسال به تفکیک منابع محاسبه می‌شود.'}</p>`;
}
async function buildOutfit(){
 if(!products.length)return;
 const budget=Number($('budget').value);$('budget-label').innerHTML=price(budget);
 anchor??=products.find(p=>p.category==='Top'&&p.stock>0)??products[0];
 if(config.mode==='live'){
  try{const result=await api(`/match-outfit?product_id=${anchor.id}&budget=${budget}&occasion=${encodeURIComponent(occasion)}&seed=${outfitSeed}`);outfit=result.items?result:null;}catch(e){outfit=null;$('builder-status').textContent=e.message;}
 }else outfit=matchOutfit(products,anchor,budget,occasion,outfitSeed);
 if(!outfit){$('outfit-items').innerHTML='<div class="outfit-none"><strong>برای این انتخاب، ست کاملی پیدا نشد.</strong><p>بودجه را بیشتر کن یا موقعیت و تکهٔ اول را تغییر بده.</p></div>';$('outfit-price').textContent='—';$('outfit-savings').textContent='';$('add-bundle').disabled=true;$('builder-status').textContent='سه منبع متفاوت، با رعایت سقف بودجه';return;}
 $('outfit-items').innerHTML=outfit.items.map((p,i)=>`<article class="outfit-card"><span class="outfit-category">${['THE TOP','THE BOTTOM','THE FINISH'][i]}</span><button class="outfit-img" data-open-product="${p.id}" aria-label="جزئیات ${esc(p.title)}"><img src="${esc(img(p))}" alt="${esc(p.title)}" loading="lazy"><span class="outfit-source">${esc(p.sourceName)}</span></button><h3>${esc(p.title)}</h3><p class="outfit-item-price">${price(p.price)}</p></article>`).join('');
 const discount=Math.floor(outfit.total*config.bundleDiscountPercent/100);$('outfit-price').innerHTML=price(outfit.total-discount);$('outfit-savings').textContent=discount?`${toman(discount)} تومان تخفیف ${config.mode==='demo'?'نمونه برای ':''}ست مستقیم`:'سه انتخاب هماهنگ، در سقف بودجهٔ تو';$('look-number').textContent=String(outfitSeed+1).padStart(3,'0');$('add-bundle').disabled=false;$('builder-status').textContent=`سه منبع متفاوت · هماهنگ با ${occasion==='office'?'روز کاری':occasion==='date'?'قرار عصرانه':'حال‌وهوای شهری'}`;
}
function chooseAnchor(id){const p=products.find(p=>p.id===Number(id));if(!p)return;anchor=p;outfitSeed=0;void buildOutfit();closeDialog('product-dialog');$('builder').scrollIntoView({behavior:'smooth'});notify(`${p.title} به استایلت اضافه شد.`);}
function showBundle(){if(!outfit)return;$('bundle-form').innerHTML=outfit.items.map(p=>`<label class="bundle-row"><img src="${esc(img(p))}" alt="${esc(p.title)}"><span><strong>${esc(p.title)}</strong><small>${esc(p.sourceName)}</small></span><select name="size-${p.id}" required aria-label="سایز ${esc(p.title)}">${p.sizes.filter(s=>s.stock>0).map(s=>`<option value="${esc(s.label)}">${esc(s.label)}</option>`).join('')}</select></label>`).join('')+`<button class="button gold bundle-submit" type="submit">افزودن هر سه تکه · ${price(outfit.total-Math.floor(outfit.total*config.bundleDiscountPercent/100))}</button><p style="font-size:9px;margin-top:15px;color:#8c97a6">${config.mode==='demo'?'این یک سبد نمایشی است.':'تخفیف پس از اعتبارسنجی ست در سبد اصلی اعمال می‌شود.'}</p>`;openDialog('bundle-dialog');}
function updateFit(){
 if(!fitProduct)return;
 let body=fitMode==='reference'?referenceBody($('reference-size').value):{chest:Number($('chest').value),waist:Number($('waist').value),shoulder:Number($('shoulder').value)};
 if(fitMode==='measure'){
  const valid=['height','weight','chest','waist','shoulder'].every(id=>$(id).checkValidity());
  if(!valid){$('fit-confidence').textContent='اندازه‌های معتبر را در محدودهٔ مشخص‌شده وارد کن.';return;}
 }
 const r=recommendSize(fitProduct.sizes,body,$('fit-preference').value);if(!r){$('recommended-size').textContent='—';$('fit-confidence').textContent='جدول اندازهٔ قابل اتکا موجود نیست.';return;}
 $('recommended-size').textContent=r.label;$('fit-product-name').textContent=fitProduct.title;$('fit-confidence').textContent=`${r.available?'سایز پیشنهادی موجود است':'سایز مناسب فعلاً موجود نیست'} · ${fitMode==='reference'?'تخمین با اطمینان پایین':'مقایسهٔ اندازه‌ها'}${fitProduct.demo?' · جدول نمونه':''}`;
 $('chest-display').textContent=toman(body.chest)+' cm';$('waist-display').textContent=toman(body.waist)+' cm';
 const colors={perfect:'#78c6a5',snug:'#ddb76a',loose:'#719fda'};for(const f of ['chest','waist','shoulder']){const e=$('heat-'+f);e.setAttribute(f==='shoulder'?'stroke':'fill',colors[r.heat[f]??'perfect']);}
 const height=fitMode==='measure'?Number($('height').value):178;const sx=Math.max(.85,Math.min(1.15,body.chest/102));const sy=Math.max(.9,Math.min(1.08,height/178));$('avatar-shape').setAttribute('transform',`translate(150 240) scale(${sx} ${sy}) translate(-150 -240)`);
 $('fit-chip').textContent=r.available?`سایز ${r.label} · ${Object.values(r.heat).includes('snug')?'در بعضی نواحی چسبان‌تر':Object.values(r.heat).includes('loose')?'فیت آزادتر':'فیت متعادل'}`:`سایز مناسب ${r.label} فعلاً ناموجود است`;
}
function setFitMode(mode){fitMode=mode;document.querySelectorAll('[data-fit-mode]').forEach(b=>{b.classList.toggle('selected',b.dataset.fitMode===mode);b.setAttribute('aria-pressed',String(b.dataset.fitMode===mode));});for(const m of ['reference','measure','photo'])$('fit-'+m).hidden=m!==mode;$('fit-preferences').hidden=mode==='photo';if(mode!=='photo')updateFit();}
function previewPhoto(file){if(!file||!['image/jpeg','image/png','image/webp'].includes(file.type)||file.size>8*1024*1024){notify('عکس JPG، PNG یا WEBP با حجم کمتر از ۸ مگابایت انتخاب کن.');return;}if(photoURL)URL.revokeObjectURL(photoURL);photoFile=file;photoURL=URL.createObjectURL(file);$('photo-preview').src=photoURL;$('photo-preview').hidden=false;$('photo-status').textContent=config.vton?.enabled?'عکس هنوز ارسال نشده است. برای پرو تصویری، رضایت‌نامهٔ ارائه‌دهنده را بخوان و دکمهٔ ارسال را بزن.':'عکس در همین مرورگر پیش‌نمایش شده و جایی ارسال نشده است. سرویس خارجی پرو با عکس هنوز فعال نیست.';}
async function runVton(button){
 if(!photoFile||!fitProduct){notify('ابتدا عکس و لباس را انتخاب کن.');return;}
 if(!$('vton-consent')?.checked){notify('برای ارسال عکس به ارائه‌دهنده، رضایت جداگانه لازم است.');return;}
 button.disabled=true;$('photo-status').textContent='عکس با رضایت تو به ارائه‌دهنده ارسال می‌شود؛ ممکن است صف یا محدودیت ظرفیت داشته باشد.';
 try{const {virtualTryOn}=await import('./vton.mjs');const url=await virtualTryOn({space:config.vton.space,photo:photoFile,garmentUrl:new URL(img(fitProduct),location.href).href,description:fitProduct.title,consent:true,commercialUseAuthorized:config.vton.commercialUseAuthorized,apiName:config.vton.apiName??'/tryon'});let result=$('vton-result');if(!result){result=document.createElement('img');result.id='vton-result';result.className='vton-result';result.alt='خروجی آزمایشی پرو تصویری؛ نمایش، تضمین سایز و فیت واقعی نیست.';$('fit-photo').append(result);}result.src=url;$('photo-status').textContent='پیش‌نمایش تصویری آماده شد؛ این تصویر تضمین سایز یا فیت واقعی نیست.';}catch(e){$('photo-status').textContent='سرویس پرو در دسترس نیست یا اتصال رد شد: '+e.message;}finally{button.disabled=false;}
}
function info(kind){const map={
 about:['یک شروع تازه برای دالاس','این نسخه، پیش‌نمایش تعاملی فروشگاه مردانهٔ دالاس است. کالاها، قیمت‌ها، شرایط اقساط و موجودی‌ها نمونه‌اند و از فروشگاه‌های منبع دریافت نشده‌اند.','ساخت ست، فیلترها، سبد انتخاب‌ها و راهنمای سایز در مرورگر کار می‌کنند. اتصال فروش واقعی به هاست وردپرس، تأیید منابع و حساب‌های فروشنده نیاز دارد.'],
 privacy:['حریم شخصی، انتخاب خودت','علاقه‌مندی‌ها و سبد نمونه فقط در مرورگر خودت ذخیره می‌شوند. اندازه‌های بدن و عکس انتخابی در این نسخه به سرور ارسال نمی‌شوند.','اگر سرویس خارجی پرو با عکس در آینده فعال شود، پیش از ارسال عکس، نام ارائه‌دهنده و رضایت تو به‌صورت جداگانه نمایش داده خواهد شد.'],
 shipping:['خرید از چند منبع، با آگاهی بیشتر','در نسخهٔ فروش واقعی، هر کالا باید موجودی تأییدشده، شیوهٔ ارسال و شرایط مرجوعی مشخص داشته باشد. کالاهای منابع مختلف ممکن است در بسته‌های جداگانه برسند.','خرید اقساطی در فروشگاه منبع انجام می‌شود و شرایط نهایی همان فروشگاه معتبر است. در این نسخه پرداخت و ثبت سفارش غیرفعال است.'],
 checkout:['سبد نمونه‌ات آماده است','انتخاب‌هایت در مرورگر ذخیره شد. این نسخه به درگاه پرداخت یا فروشگاه واقعی متصل نیست؛ سفارش و پرداختی ثبت نشده است.','برای فعال‌سازی فروش واقعی، راهنمای هاست و بستهٔ وردپرس آماده شده است.'],
 affiliate:['خرید اقساطی در فروشگاه منبع','در این پیش‌نمایش، لینک افیلیت و پرداخت اقساطی فعال نیست. مبلغ یک‌چهارم صرفاً برای نمایش رابط کاربری است.','در نسخهٔ واقعی تنها شرایط اقساط تأییدشده و لینک مجاز همان محصول نمایش داده می‌شود.']
};
if(config.mode==='live'){
 map.about=['به دالاس خوش آمدی','دالاس فضایی برای کشف پوشاک مردانه و ساختن استایل شخصی از میان منابع مختلف است. هر محصول، اطلاعات همان فروشگاه و زمان دریافت خود را دارد.','پیش از پرداخت، موجودی سایز و مبلغ نهایی سبد را بررسی کن. خرید اقساطی در فروشگاه منبع، مسیر و شرایط خودش را دارد.'];
 map.privacy=['حریم شخصی، انتخاب خودت','علاقه‌مندی‌ها و اندازه‌های راهنمای فیت در مرورگر خودت پردازش می‌شوند. هنگام ثبت سفارش، اطلاعات تماس و ارسال برای رسیدگی به سفارش در فروشگاه ذخیره می‌شود و اطلاعات لازم ممکن است برای تأمین و ارسال به مسئول سفارش و تأمین‌کننده منتقل شود.','ارسال عکس به سرویس خارجی فقط پس از معرفی ارائه‌دهنده و رضایت جداگانه انجام می‌شود.'];
 map.shipping=['انتخاب آگاهانه برای خرید','مبلغ کالا و هزینهٔ ارسال در مرحلهٔ نهایی سبد نمایش داده می‌شوند. سفارش از چند منبع ممکن است در چند بسته ارسال شود. پیش از پرداخت، روش ارسال و شرایط مرجوعی همان محصول را بررسی کن.','خرید اقساطی در فروشگاه منبع انجام می‌شود و شرایط نهایی همان فروشگاه معتبر است.'];
}
const [title,...paragraphs]=map[kind]??map.about;$('info-content').innerHTML=`<div class="eyebrow">DALLASSS / GOOD TO KNOW</div><h2>${title}</h2>${paragraphs.map(p=>`<p>${p}</p>`).join('')}${config.mode==='demo'&&(kind==='about'||kind==='checkout')?'<a class="button outline" href="./implementation.html">راهنمای اجرا و فایل‌های فنی ↗</a>':''}`;openDialog('info-dialog');}

document.addEventListener('click',event=>{
 const b=event.target.closest('button,a,[data-open-product]');if(!b)return;
 if(b.dataset.favorite){event.stopPropagation();const id=Number(b.dataset.favorite);favorites.has(id)?favorites.delete(id):favorites.add(id);renderCatalog();notify(favorites.has(id)?'به کمد علاقه‌مندی‌ها اضافه شد.':'از علاقه‌مندی‌ها حذف شد.');return;}
 if(b.dataset.toOutfit){chooseAnchor(b.dataset.toOutfit);return;}
 if(b.dataset.openProduct){showProduct(b.dataset.openProduct);return;}
 if(b.dataset.close){closeDialog(b.dataset.close);return;}
 if(b.dataset.occasion){selectOccasion(b.dataset.occasion);return;}
 if(b.dataset.fitMode){setFitMode(b.dataset.fitMode);return;}
 if(b.dataset.size){currentSize=b.dataset.size;renderDetail();return;}
 if(b.dataset.color){currentColor=b.dataset.color;renderDetail();return;}
 if(b.dataset.remove!==undefined){cart.splice(Number(b.dataset.remove),1);renderCart();return;}
 if(b.dataset.quantity!==undefined){const l=cart[Number(b.dataset.quantity)],delta=Number(b.dataset.delta);if(delta>0)addLine(l.id,l.size,1,l.color);else if(l.quantity===1)cart.splice(Number(b.dataset.quantity),1);else l.quantity--;renderCart();return;}
 if(b.dataset.slide!==undefined){const index=Number(b.dataset.slide);const slides=[['hero.jpg','استایل تو،<br><em>قانون تو.</em>','از شلوغیِ انتخاب‌ها عبور کن.<br>بهترین تکه‌ها را پیدا کن و استایلی بساز که شبیه خودت باشد.'],['editorial.jpg','کمتر انتخاب کن،<br><em>بهتر بپوش.</em>','کمدی از ضروری‌های ماندگار.<br>از تکه‌های ساده شروع کن و امضای خودت را بساز.'],['hero.jpg','لایه به لایه،<br><em>شبیه خودت.</em>','برای هوای تازهٔ شهر آماده شو.<br>پاییز را با انتخاب‌های شخصی خودت بپوش.']];$('hero-img').src=asset(slides[index][0]);$('hero-img').alt=['استایل شهری مردانه در فضای باز','گزیده‌ای از پوشاک روزمره','کت زمستانی مردانه'][index];$('hero-title').innerHTML=slides[index][1];$('hero-copy').innerHTML=slides[index][2];document.querySelectorAll('[data-slide]').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));return;}
 const action=b.dataset.action;
 if(['about','privacy','shipping'].includes(action)){info(action);return;}
 if(action==='cart'){renderCart();openDialog('cart-dialog');}
 if(action==='favorites'){favoritesOnly=!favoritesOnly;visible=12;renderCatalog();$('edit').scrollIntoView({behavior:'smooth'});}
 if(action==='search'){$('search-panel').hidden=false;$('edit').scrollIntoView({behavior:'smooth'});$('search-input').focus();}
 if(action==='close-search'){$('search-panel').hidden=true;query='';$('search-input').value='';renderCatalog();}
 if(action==='filters')$('filters-panel').hidden=!$('filters-panel').hidden;
 if(action==='menu')$('mobile-nav').hidden=!$('mobile-nav').hidden;
 if(action==='clear-filters')clearFilters();
 if(action==='more'){visible+=4;renderCatalog();}
 if(action==='continue-shopping'){closeDialog('cart-dialog');$('edit').scrollIntoView({behavior:'smooth'});}
 if(action==='add-current'&&addLine(currentProduct.id,currentSize,1,currentColor)){closeDialog('product-dialog');notify('به سبد انتخاب‌ها اضافه شد.');}
 if(action==='fit-current'){fitProduct=currentProduct;updateFit();closeDialog('product-dialog');$('fitting').scrollIntoView({behavior:'smooth'});}
 if(action==='affiliate-current'){
  if(config.mode==='demo')info('affiliate');else if(currentProduct.affiliateUrl&&/^https:\/\//.test(currentProduct.affiliateUrl))window.open(currentProduct.affiliateUrl,'_blank','noopener,noreferrer');else notify('لینک اقساطی تأییدشده برای این کالا فعال نیست.');
 }
 if(action==='checkout')void checkout(b);
 if(action==='run-vton')void runVton(b);
 if(b.closest('.mobile-nav'))$('mobile-nav').hidden=true;
});
document.addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&e.target.matches('.product-image')){e.preventDefault();showProduct(e.target.dataset.openProduct);}});
for(const d of document.querySelectorAll('dialog'))d.addEventListener('click',e=>{if(e.target===d){const r=d.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)closeDialog(d.id);}});
$('source-filter').addEventListener('change',e=>{source=e.target.value;visible=12;renderCatalog();});$('category-filter').addEventListener('change',e=>{category=e.target.value;visible=12;renderCatalog();});$('sort-filter').addEventListener('change',e=>{sort=e.target.value;renderCatalog();});$('search-input').addEventListener('input',e=>{query=e.target.value;visible=12;renderCatalog();});
$('view-all').addEventListener('click',()=>{visible=products.length;renderCatalog();});
let budgetTimer;$('budget').addEventListener('input',()=>{$('budget-label').innerHTML=price(Number($('budget').value));clearTimeout(budgetTimer);budgetTimer=setTimeout(()=>void buildOutfit(),config.mode==='live'?350:0);});
$('shuffle-outfit').addEventListener('click',()=>{outfitSeed++;void buildOutfit();});$('add-bundle').addEventListener('click',showBundle);
$('bundle-form').addEventListener('submit',e=>{e.preventDefault();if(!outfit)return;const chosen=outfit.items.map(p=>({p,size:new FormData(e.target).get('size-'+p.id)}));for(const {p,size}of chosen){const s=p.sizes.find(s=>s.label===size);const c=cart.filter(l=>l.id===p.id&&l.size===size).reduce((n,l)=>n+l.quantity,0);if(!s||c>=s.stock){notify('موجودی یکی از سایزها کافی نیست.');return;}}for(const {p,size}of chosen)addLine(p.id,size);closeDialog('bundle-dialog');notify('هر سه تکه به سبد انتخاب‌ها اضافه شد.');});
for(const id of ['reference-size','fit-preference','height','weight','chest','waist','shoulder'])$(id).addEventListener(id==='reference-size'||id==='fit-preference'?'change':'input',updateFit);
$('photo-input').addEventListener('change',e=>previewPhoto(e.target.files[0]));$('photo-drop').addEventListener('dragover',e=>{e.preventDefault();e.currentTarget.classList.add('dragging');});$('photo-drop').addEventListener('dragleave',e=>e.currentTarget.classList.remove('dragging'));$('photo-drop').addEventListener('drop',e=>{e.preventDefault();e.currentTarget.classList.remove('dragging');previewPhoto(e.dataTransfer.files[0]);});window.addEventListener('pagehide',()=>{if(photoURL)URL.revokeObjectURL(photoURL);});
async function checkout(button){
 if(config.mode==='demo'){info('checkout');return;}
 button.disabled=true;try{const result=await api('/cart/add',{method:'POST',body:JSON.stringify({items:cart.map(l=>({product_id:l.id,size:l.size,color:l.color,quantity:l.quantity})),bundle:outfit?.items.map(p=>p.id)??[]})});const target=new URL(result.checkout_url,location.origin);if(target.origin!==location.origin)throw new Error('آدرس پرداخت معتبر نیست.');location.assign(target.href);}catch(e){notify(e.message);button.disabled=false;}
}
async function start(){
 if(config.vton?.enabled&&config.vton.commercialUseAuthorized){const controls=document.createElement('div');controls.innerHTML=`<label class="photo-consent"><input id="vton-consent" type="checkbox"><span>موافقم این عکس و تصویر لباس برای پردازش به Hugging Face Space با شناسهٔ ${esc(config.vton.space)} ارسال شود. سهمیه، زمان انتظار و نگهداری عکس تابع مقررات ارائه‌دهنده است.</span></label><button class="button gold" data-action="run-vton">ارسال عکس و اجرای پرو تصویری</button>`;$('fit-photo').append(controls);}
 if(config.mode==='live'){
  document.querySelector('.rack-bottom p').innerHTML='<span class="status-dot"></span> <span id="results-count"></span> انتخاب · برای جزئیات، روی هر لباس بزن';
  $('demo-notice').textContent='دالاس · انتخاب از میان منابع تأییدشده';$('product-grid').innerHTML='<div class="loading-state">در حال دریافت انتخاب‌های تازه…</div>';
  try{const data=await api('/catalog?per_page=60');products=data.products;for(const p of products){p.occasions??=['street','date','office'];p.colors??=[p.color??'#333333'];p.english??='DALLASSS SELECTION';p.tags??=['Casual'];}cart=validateCart(cart,products);document.querySelector('.source-note').innerHTML='زمان آخرین دریافت<br>در جزئیات هر محصول';}catch(e){$('product-grid').innerHTML='<div class="empty-state"><h3>ارتباط با کاتالوگ برقرار نشد.</h3><p>کمی بعد دوباره امتحان کن. محصولات نمونه جایگزین کاتالوگ واقعی نمی‌شوند.</p></div>';$('builder-status').textContent='کاتالوگ فروشگاه در دسترس نیست';return;}
 }
 cart=validateCart(cart,products);renderCatalog();fitProduct=products.find(p=>p.category==='Top'&&p.sizes.some(s=>s.chest));updateFit();await buildOutfit();
}
await start();

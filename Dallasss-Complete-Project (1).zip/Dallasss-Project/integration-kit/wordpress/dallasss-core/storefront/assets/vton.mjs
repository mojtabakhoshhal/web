/** Optional commercial-authorized Gradio integration. No photo leaves the browser without explicit consent. */
export async function virtualTryOn({space,photo,garmentUrl,description,consent,commercialUseAuthorized,apiName='/tryon'}) {
 if(!consent)throw new Error('پیش از ارسال عکس، رضایت جداگانه لازم است.');
 if(!commercialUseAuthorized)throw new Error('مجوز استفادهٔ تجاری این ارائه‌دهنده تأیید نشده است.');
 if(!/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(space??''))throw new Error('شناسهٔ Space معتبر نیست.');
 if(!(photo instanceof File)||!['image/jpeg','image/png','image/webp'].includes(photo.type)||photo.size>8*1024*1024)throw new Error('عکس معتبر تا ۸ مگابایت انتخاب کن.');
 if(!/^https:\/\//.test(garmentUrl))throw new Error('تصویر لباس باید آدرس عمومی HTTPS داشته باشد.');
 const {Client,handle_file}=await import('https://cdn.jsdelivr.net/npm/@gradio/client@2.7.1/+esm');
 const client=await Client.connect(space);
 const contract=await client.view_api();
 const endpoint=contract.named_endpoints?.[apiName];
 const expected=['dict','garm_img','garment_des','is_checked','is_checked_crop','denoise_steps','seed'];
 const names=endpoint?.parameters?.map(p=>p.parameter_name)??[];
 if(!expected.every(n=>names.includes(n)))throw new Error('امضای API این Space تغییر کرده است؛ اتصال باید دوباره بررسی شود.');
 const result=await client.predict(apiName,{
  dict:{background:handle_file(photo),layers:[],composite:null},
  garm_img:handle_file(garmentUrl),garment_des:description,
  is_checked:true,is_checked_crop:false,denoise_steps:30,seed:42
 });
 const file=result.data?.[0];const url=typeof file==='string'?file:file?.url;
 if(!url||!/^https:\/\//.test(url))throw new Error('سرویس تصویر خروجی معتبری برنگرداند.');
 return url;
}

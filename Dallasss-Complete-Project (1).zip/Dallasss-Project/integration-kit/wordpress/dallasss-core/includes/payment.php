<?php
namespace Dallasss;
defined('ABSPATH') || exit;
add_filter('woocommerce_currencies', function ($currencies) { $currencies['IRT'] = 'تومان ایران';return $currencies; });
add_filter('woocommerce_currency_symbol', function ($symbol, $currency) { return $currency === 'IRT' ? 'تومان' : $symbol; }, 10, 2);
class Zarinpal_Gateway extends \WC_Payment_Gateway {
    public function __construct() {
        $this->id = 'dallasss_zarinpal';$this->method_title = 'Dallasss / Zarinpal';$this->method_description = 'Zarinpal v4; explicit Rial wire amounts, server verification, classic WooCommerce checkout.';$this->has_fields = false;$this->supports = ['products'];
        $this->form_fields = [
            'enabled' => ['title' => 'فعال‌سازی', 'type' => 'checkbox', 'label' => 'درگاه زرین‌پال', 'default' => 'no'],
            'title' => ['title' => 'عنوان', 'type' => 'text', 'default' => 'پرداخت امن با زرین‌پال'],
            'merchant_id' => ['title' => 'Merchant ID', 'type' => 'password', 'default' => ''],
            'sandbox' => ['title' => 'Sandbox', 'type' => 'checkbox', 'label' => 'محیط آزمایشی', 'default' => 'yes'],
        ];
        $this->init_settings();$this->title = $this->get_option('title');$this->enabled = $this->get_option('enabled');
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'process_admin_options']);
        add_action('woocommerce_api_' . $this->id, [$this, 'callback']);
    }
    public function is_available() {
        return parent::is_available() && in_array(get_woocommerce_currency(), ['IRR', 'IRT'], true) && (bool) $this->get_option('merchant_id');
    }
    private function host(): string { return $this->get_option('sandbox') === 'yes' ? 'sandbox.zarinpal.com' : 'api.zarinpal.com'; }
    private function request(string $method, array $data): array {
        $r = wp_remote_post('https://' . $this->host() . '/pg/v4/payment/' . $method . '.json', ['timeout' => 20, 'redirection' => 0, 'headers' => ['Content-Type' => 'application/json'], 'body' => wp_json_encode($data)]);
        if (is_wp_error($r)) { throw new \RuntimeException('ارتباط با درگاه برقرار نشد.'); }
        $b = json_decode(wp_remote_retrieve_body($r), true);
        if (wp_remote_retrieve_response_code($r) !== 200 || !is_array($b)) { throw new \RuntimeException('پاسخ معتبر از درگاه دریافت نشد.'); }
        return $b;
    }
    private function payment_url(string $authority): string { return 'https://' . ($this->get_option('sandbox') === 'yes' ? 'sandbox.zarinpal.com' : 'www.zarinpal.com') . '/pg/StartPay/' . rawurlencode($authority); }
    public function process_payment($order_id) {
        $order = wc_get_order($order_id);if (!$order || $order->is_paid()) { return ['result' => 'success', 'redirect' => $order ? $this->get_return_url($order) : wc_get_checkout_url()]; }
        $amount = (int) round((float) $order->get_total() * ($order->get_currency() === 'IRR' ? 1 : 10));
        if ($amount < 1000) { wc_add_notice('مبلغ سفارش برای پرداخت معتبر نیست.', 'error');return ['result' => 'failure']; }
        $lock = 'dallasss_payment_request_' . $order_id;
        if (!add_option($lock, time(), '', false)) { wc_add_notice('درخواست پرداخت در حال بررسی است. چند لحظه بعد دوباره تلاش کن.', 'error');return ['result' => 'failure']; }
        try {
            $old = $order->get_meta('_dallasss_authority');
            if ($old && $order->get_meta('_dallasss_amount_rial') === (string) $amount && (int) $order->get_meta('_dallasss_requested_at') > time() - 900) { return ['result' => 'success', 'redirect' => $this->payment_url($old)]; }
            $callback = add_query_arg(['wc-api' => $this->id, 'order_id' => $order_id, 'key' => $order->get_order_key()], home_url('/'));
            $result = $this->request('request', ['merchant_id' => $this->get_option('merchant_id'), 'amount' => $amount, 'currency' => 'IRR', 'callback_url' => $callback, 'description' => 'Dallasss order #' . $order->get_order_number(), 'metadata' => ['mobile' => $order->get_billing_phone()]]);
            $a = $result['data']['authority'] ?? '';
            if ((int) ($result['data']['code'] ?? 0) !== 100 || !preg_match('/^[A-Za-z0-9]{20,64}$/', $a)) { throw new \RuntimeException('ایجاد پرداخت توسط درگاه تأیید نشد.'); }
            $order->update_meta_data('_dallasss_authority', $a);$order->update_meta_data('_dallasss_amount_rial', (string) $amount);$order->update_meta_data('_dallasss_requested_at', time());$order->save();
            return ['result' => 'success', 'redirect' => $this->payment_url($a)];
        } catch (\Throwable $e) { wc_add_notice($e->getMessage(), 'error');return ['result' => 'failure']; }
        finally { delete_option($lock); }
    }
    public function callback(): void {
        $order = wc_get_order(absint($_GET['order_id'] ?? 0));$key = sanitize_text_field(wp_unslash($_GET['key'] ?? ''));
        if (!$order || !$key || !hash_equals($order->get_order_key(), $key)) { wp_die('Invalid payment callback.', '', ['response' => 403]); }
        if ($order->is_paid()) { wp_safe_redirect($this->get_return_url($order));exit; }
        $a = sanitize_text_field(wp_unslash($_GET['Authority'] ?? ''));
        if (!$a || !hash_equals((string) $order->get_meta('_dallasss_authority'), $a)) { wp_die('Payment authority does not match this order.', '', ['response' => 403]); }
        if (sanitize_text_field(wp_unslash($_GET['Status'] ?? '')) !== 'OK') { $order->add_order_note('Customer returned without a successful payment status. No payment was accepted.');wp_safe_redirect($order->get_checkout_payment_url());exit; }
        $lock = 'dallasss_payment_verify_' . $order->get_id();
        if (!add_option($lock, time(), '', false)) { wp_die('Payment verification in progress. Refresh shortly.', '', ['response' => 409]); }
        try {
            $amount = (int) $order->get_meta('_dallasss_amount_rial');if ($amount < 1000) { throw new \RuntimeException('مبلغ ثبت‌شدهٔ پرداخت معتبر نیست.'); }
            $r = $this->request('verify', ['merchant_id' => $this->get_option('merchant_id'), 'amount' => $amount, 'authority' => $a]);
            $code = (int) ($r['data']['code'] ?? 0);$ref = (string) ($r['data']['ref_id'] ?? '');
            if (!in_array($code, [100, 101], true) || !$ref) { throw new \RuntimeException('تأیید سروری پرداخت کامل نشد. وضعیت تراکنش را بررسی کن.'); }
            $order->payment_complete($ref);$order->add_order_note('Zarinpal server verification successful. Reference: ' . sanitize_text_field($ref));
            if (WC()->cart) { WC()->cart->empty_cart(); }
            wp_safe_redirect($this->get_return_url($order));
        } catch (\Throwable $e) { $order->add_order_note($e->getMessage());wc_add_notice($e->getMessage(), 'error');wp_safe_redirect($order->get_checkout_payment_url()); }
        finally { delete_option($lock); }
        exit;
    }
}
add_filter('woocommerce_payment_gateways', function ($gateways) { $gateways[] = __NAMESPACE__ . '\\Zarinpal_Gateway';return $gateways; });

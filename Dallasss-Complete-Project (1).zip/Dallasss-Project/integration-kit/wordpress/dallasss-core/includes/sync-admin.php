<?php
namespace Dallasss;
defined('ABSPATH') || exit;
add_action('rest_api_init', function () {
    register_rest_route('dallasss/v1', '/sync/policy', ['methods' => 'GET', 'permission_callback' => __NAMESPACE__ . '\\admin_permission', 'callback' => function () {
        $s = settings();if (!in_array(get_woocommerce_currency(), ['IRR', 'IRT'], true)) { return new \WP_Error('wrong_currency', 'Set WooCommerce currency to IRT or IRR before import.', ['status' => 409]); }
        return ['markup_bps' => (int) $s['markup_bps'], 'shipping_buffer' => (int) $s['shipping_buffer'], 'rounding' => (int) $s['rounding'], 'currency' => get_woocommerce_currency()];
    }]);
    register_rest_route('dallasss/v1', '/sync/finalize', ['methods' => 'POST', 'permission_callback' => __NAMESPACE__ . '\\admin_permission', 'callback' => function ($r) {
        $parent = wc_get_product((int) $r['product_id']);$p = product_payload($parent);
        if (!$parent || !$parent->is_type('variable') || !$p || $p['source_hash'] !== $r['source_hash'] || $p['observed_at'] !== $r['observed_at'] || !fresh($p)) { return new \WP_Error('quote_changed', 'Import quote differs or expired; reconcile again.', ['status' => 409]); }
        $children = [];
        foreach ($parent->get_children() as $id) { $v = wc_get_product($id);if ($v) { $children[$v->get_meta('_dallasss_variant_key')] = $v; } }
        $keys = [];
        foreach ($p['variants'] as $variant) {
            $key = $variant['key'];$keys[] = $key;
            if (!isset($children[$key])) { return new \WP_Error('incomplete_import', 'A source size is missing from WooCommerce.', ['status' => 409]); }
            $v = $children[$key];$price = from_toman(sell_price($variant['source_price_toman']));
            if ((int) $v->get_regular_price('edit') !== $price) { return new \WP_Error('price_differs', 'Variant price does not match the server pricing policy.', ['status' => 409]); }
        }
        foreach ($children as $key => $v) {
            $source_stock = null;foreach ($p['variants'] as $variant) { if ($variant['key'] === $key) { $source_stock = $variant['quantity'];break; } }
            $quantity = settings()['direct_enabled'] ? effective_stock($v->get_id(), $source_stock) : 0;
            wc_update_product_stock($v, $quantity, 'set');$v->set_stock_status($quantity > 0 ? 'instock' : 'outofstock');$v->save();
        }
        delete_post_meta($parent->get_id(), '_dallasss_sync_state');\WC_Product_Variable::sync($parent->get_id());
        update_option('dallasss_feed_revision', microtime(true), false);return ['finalized' => true];
    }]);
    register_rest_route('dallasss/v1', '/sync/mapping', ['methods' => 'POST', 'permission_callback' => __NAMESPACE__ . '\\admin_permission', 'callback' => function ($r) {
        $rows = $r->get_param('items');if (!is_array($rows) || count($rows) > 20) { return new \WP_Error('mapping_limit', 'At most 20 mappings per request.', ['status' => 422]); }
        foreach ($rows as $row) {
            $v = wc_get_product(absint($row['wc_variation_id'] ?? 0));$seller_id = absint($row['digikala_variant_id'] ?? 0);
            if (!$v || !$v->is_type('variation') || !product_payload($v) || !$seller_id) { return new \WP_Error('invalid_mapping', 'Map real WooCommerce variations to real seller variant IDs.', ['status' => 422]); }
            $duplicates = wc_get_products(['type' => 'variation', 'limit' => 2, 'meta_key' => '_dallasss_digikala_variant_id', 'meta_value' => $seller_id]);
            foreach ($duplicates as $other) { if ($other->get_id() !== $v->get_id()) { return new \WP_Error('duplicate_mapping', 'Seller variant already belongs to another garment.', ['status' => 409]); } }
            $v->update_meta_data('_dallasss_digikala_variant_id', $seller_id);$v->save();
        }
        return ['mapped' => count($rows)];
    }]);
});

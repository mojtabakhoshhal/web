<?php
namespace Dallasss;
defined('ABSPATH') || exit;
add_shortcode('dallasss_storefront', function () {
    $base = plugins_url('storefront/assets/', DALLASSS_CORE_FILE);
    wp_enqueue_style('dallasss-tailwind', $base . 'tailwind.css', [], '1.0.0');
    wp_enqueue_style('dallasss-storefront', $base . 'style.css', ['dallasss-tailwind'], '1.0.0');
    wp_enqueue_script('dallasss-app', $base . 'app.mjs', [], '1.0.0', true);
    wp_add_inline_script('dallasss-app', 'window.DALLASSS_CONFIG=' . wp_json_encode(['mode' => 'live', 'apiBase' => untrailingslashit(rest_url('dallasss/v1')), 'assetBase' => $base, 'nonce' => wp_create_nonce('wp_rest'), 'bundleDiscountPercent' => settings()['bundle_percent'], 'vton' => get_option('dallasss_vton', ['enabled' => false])]) . ';', 'before');
    return str_replace('./assets/', $base, file_get_contents(DALLASSS_CORE_DIR . '/storefront/storefront.html'));
});
add_filter('script_loader_tag', function ($tag, $handle) { return $handle === 'dallasss-app' ? str_replace(' src=', ' type="module" src=', preg_replace('/ type=["\']text\/javascript["\']/', '', $tag)) : $tag; }, 10, 2);
add_action('woocommerce_after_single_product_summary', function () {
    global $product;$p = $product ? api_product($product->get_id()) : null;if (!$p || $p['category'] !== 'Top') { return; }
    wp_enqueue_script('dallasss-product-fit', plugins_url('storefront/assets/product-fit.mjs', DALLASSS_CORE_FILE), [], '1.0.0', true);
    echo '<section data-dallasss-fit data-chart="' . esc_attr(wp_json_encode($p['sizes'])) . '" style="clear:both;padding:30px 0;border-top:1px solid #ffffff20"><h2>راهنمای فیت این لباس</h2><p>نمایش شماتیک و پیشنهاد تقریبی؛ جدول فروشنده مرجع نهایی است.</p><div style="display:flex;gap:30px;flex-wrap:wrap;align-items:center"><svg viewBox="0 0 160 240" style="width:160px;height:240px;stroke:none"><g data-male><circle cx="80" cy="28" r="17" fill="#7b8794"/><path d="M62 48H98L119 70 127 125 111 129 99 89 99 151 103 222H84L80 163 76 222H57L61 151 61 89 49 129 33 125 41 70Z" fill="#354557"/><ellipse data-heat="chest" cx="80" cy="78" rx="20" ry="12" fill="#78c6a5"/><ellipse data-heat="waist" cx="80" cy="127" rx="19" ry="9" fill="#78c6a5"/><ellipse data-heat="shoulder" cx="80" cy="56" rx="25" ry="4" fill="#78c6a5"/></g></svg><div style="flex:1;max-width:400px">';
    foreach (['chest' => ['دور سینه', 102, 65, 160], 'waist' => ['دور کمر', 88, 55, 160], 'shoulder' => ['عرض شانه', 47, 30, 70]] as $key => $field) { echo '<label style="display:block">' . esc_html($field[0]) . ' (cm)<input type="number" name="' . esc_attr($key) . '" value="' . $field[1] . '" min="' . $field[2] . '" max="' . $field[3] . '"></label>'; }
    echo '<label>فیت دلخواه<select name="preference"><option value="regular">متعادل</option><option value="slim">نزدیک به بدن</option><option value="loose">آزاد</option></select></label><output aria-live="polite" style="display:block;margin-top:15px;color:#c9b47d"></output><p>سبز: متناسب · کهربایی: چسبان · آبی: آزاد</p></div></div></section>';
}, 5);
add_filter('script_loader_tag', function ($tag, $handle) { return $handle === 'dallasss-product-fit' ? str_replace(' src=', ' type="module" src=', preg_replace('/ type=["\']text\/javascript["\']/', '', $tag)) : $tag; }, 10, 2);

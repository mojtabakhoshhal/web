<?php
namespace Dallasss;
defined('ABSPATH') || exit;
function validate_payload(array $p) {
    $s = settings();
    $source = $p['source'] ?? '';
    if (!in_array($source, $s['approved_sources'], true)) { return new \WP_Error('supplier_not_approved', 'Supplier has not been approved.', ['status' => 422]); }
    if (!public_https($p['source_url'] ?? '', $s['source_hosts'][$source] ?? [])) { return new \WP_Error('invalid_source_url', 'Unapproved supplier hostname.', ['status' => 422]); }
    if (empty($p['source_id']) || !is_string($p['source_id']) || strlen($p['source_id']) > 191 || !preg_match('/^#[0-9a-fA-F]{6}$/', $p['color'] ?? '')) { return new \WP_Error('invalid_identity', 'Stable source_id and a hex color are required.', ['status' => 422]); }
    $hash = md5($source . '|' . $p['source_id']);
    if (!hash_equals($hash, $p['source_hash'] ?? '')) { return new \WP_Error('invalid_hash', 'Source identity hash differs.', ['status' => 422]); }
    if (!is_int($p['source_price_toman'] ?? null) || $p['source_price_toman'] < 1 || $p['source_price_toman'] > 1000000000) { return new \WP_Error('invalid_price', 'Positive integer Toman price required.', ['status' => 422]); }
    if (!fresh($p) || count($p['variants'] ?? []) > 40 || empty($p['variants']) || !in_array($p['category'] ?? '', ['Top', 'Bottom', 'Footwear', 'Accessory'], true)) { return new \WP_Error('invalid_quote', 'Quote is stale, category invalid, or variant limit exceeded.', ['status' => 422]); }
    if (!is_array($p['tags'] ?? null) || !is_array($p['occasions'] ?? null) || array_diff($p['tags'], ['Top', 'Bottom', 'Footwear', 'Accessory', 'Formal', 'Casual', 'Streetwear']) || array_diff($p['occasions'], ['street', 'date', 'office']) || !in_array($p['fit'] ?? '', ['Slim', 'Regular', 'Oversized'], true)) { return new \WP_Error('invalid_attributes', 'Normalized style attributes are invalid.', ['status' => 422]); }
    if (empty($p['images']) || count($p['images']) > 8) { return new \WP_Error('invalid_images', 'One to eight permitted CDN images required.', ['status' => 422]); }
    foreach ($p['images'] as $url) { if (!is_string($url) || !public_https($url, $s['image_hosts'])) { return new \WP_Error('invalid_image_host', 'CDN hostname is not allowlisted.', ['status' => 422]); } }
    $keys = [];
    foreach ($p['variants'] as $v) {
        if (empty($v['key']) || empty($v['size']) || isset($keys[$v['key']]) || !preg_match('/^[A-Za-z0-9._-]{1,70}$/', $v['key']) || strlen($v['size']) > 50 || !is_int($v['source_price_toman'] ?? null) || $v['source_price_toman'] < 1 || $v['source_price_toman'] > 1000000000 || !((isset($v['quantity']) && is_int($v['quantity']) && $v['quantity'] >= 0 && $v['quantity'] <= 10000) || array_key_exists('quantity', $v) && $v['quantity'] === null)) {
            return new \WP_Error('invalid_variant', 'Invalid or duplicate variant, price or stock.', ['status' => 422]);
        }
        $keys[$v['key']] = true;
    }
    $p['title'] = sanitize_text_field($p['title'] ?? '');
    if ($p['title'] === '') { return new \WP_Error('invalid_title', 'Product title required.', ['status' => 422]); }
    return $p;
}
add_filter('rest_pre_dispatch', function ($result, $server, $request) {
    if ($request->get_method() === 'POST' && preg_match('~/wc/v3/products(?:/\d+/variations)?/batch$~', $request->get_route())) {
        $count = count((array) $request->get_param('create')) + count((array) $request->get_param('update')) + count((array) $request->get_param('delete'));
        if ($count > 20) { return new \WP_Error('batch_limit', 'Dallasss shared-host batch limit is 20.', ['status' => 413]); }
    }
    return $result;
}, 10, 3);
add_filter('woocommerce_rest_pre_insert_product_object', function ($product, $request, $creating) {
    $p = null;
    foreach ((array) $request->get_param('meta_data') as $meta) { if (($meta['key'] ?? '') === '_dallasss_payload') { $p = $meta['value']; } }
    if ($p === null) { return $product; }
    if (!is_array($p)) { return new \WP_Error('invalid_payload', 'Payload must be an object.', ['status' => 422]); }
    $p = validate_payload($p);if (is_wp_error($p)) { return $p; }
    $old = product_payload($product);
    if ($old && strtotime($old['observed_at']) > strtotime($p['observed_at'])) { return new \WP_Error('older_quote', 'An older quote cannot replace a newer quote.', ['status' => 409]); }
    $product->update_meta_data('_dallasss_payload', $p);
    $product->update_meta_data('_dallasss_sync_state', 'updating');
    $product->update_meta_data('_dallasss_source_hash', $p['source_hash']);
    $product->update_meta_data('_dallasss_source_url', $p['source_url']);
    $product->update_meta_data('_dallasss_source_price_toman', $p['source_price_toman']);
    return $product;
}, 10, 3);
add_action('woocommerce_rest_insert_product_object', function ($product) {
    $p = product_payload($product);if (!$p) { return; }
    global $wpdb;$table = $wpdb->prefix . 'dallasss_offers';$now = gmdate('Y-m-d H:i:s');
    $prev = $wpdb->get_row($wpdb->prepare("SELECT source_price_toman,selling_price_toman FROM $table WHERE source_hash=%s", $p['source_hash']), ARRAY_A);
    $selling = sell_price($p['source_price_toman']);
    if ($prev && (int) $prev['source_price_toman'] > $p['source_price_toman']) { update_post_meta($product->get_id(), '_dallasss_drop_at', time());update_post_meta($product->get_id(), '_dallasss_old_price_toman', (int) $prev['selling_price_toman']); }
    elseif ($prev && (int) $prev['source_price_toman'] < $p['source_price_toman']) { delete_post_meta($product->get_id(), '_dallasss_drop_at');delete_post_meta($product->get_id(), '_dallasss_old_price_toman'); }
    $observed = gmdate('Y-m-d H:i:s', strtotime($p['observed_at']));
    $wpdb->query($wpdb->prepare("INSERT INTO $table (source_hash,source,source_id,product_id,source_price_toman,selling_price_toman,observed_at,payload,created_at,updated_at) VALUES (%s,%s,%s,%d,%d,%d,%s,%s,%s,%s) ON DUPLICATE KEY UPDATE source_price_toman=VALUES(source_price_toman),selling_price_toman=VALUES(selling_price_toman),observed_at=VALUES(observed_at),payload=VALUES(payload),updated_at=VALUES(updated_at)", $p['source_hash'], $p['source'], $p['source_id'], $product->get_id(), $p['source_price_toman'], $selling, $observed, wp_json_encode($p), $now, $now));
    if (!$prev || (int) $prev['source_price_toman'] !== $p['source_price_toman'] || (int) $prev['selling_price_toman'] !== $selling) {
        $wpdb->query($wpdb->prepare("INSERT IGNORE INTO {$wpdb->prefix}dallasss_price_history (source_hash,source_price_toman,selling_price_toman,observed_at,observation_key) VALUES (%s,%d,%d,%s,%s)", $p['source_hash'], $p['source_price_toman'], $selling, $observed, hash('sha256', $p['source_hash'] . '|' . $observed . '|' . $p['source_price_toman'])));
    }
    assign_remote_image($product, $p);
    wp_cache_delete('catalog', 'dallasss');update_option('dallasss_feed_revision', microtime(true), false);
}, 10, 1);
add_filter('woocommerce_rest_pre_insert_product_variation_object', function ($variation, $request) {
    $parent = wc_get_product((int) $request['product_id']);$p = product_payload($parent);if (!$p) { return $variation; }
    $key = '';
    foreach ((array) $request->get_param('meta_data') as $meta) { if (($meta['key'] ?? '') === '_dallasss_variant_key') { $key = $meta['value']; } }
    if ($key === '') { $key = $variation->get_meta('_dallasss_variant_key'); }
    $variant = null;foreach ($p['variants'] as $v) { if ($v['key'] === $key) { $variant = $v;break; } }
    if (!$variant) { return new \WP_Error('unknown_variant', 'Variant is missing from supplier quote.', ['status' => 422]); }
    $stock = fresh($p) && settings()['direct_enabled'] ? effective_stock($variation->get_id(), $variant['quantity']) : 0;
    $variation->set_manage_stock(true);$variation->set_stock_quantity($stock);$variation->set_stock_status($stock > 0 ? 'instock' : 'outofstock');$variation->set_backorders('no');
    $variation->set_regular_price((string) from_toman(sell_price($variant['source_price_toman'])));$variation->set_sale_price('');
    $variation->update_meta_data('_dallasss_variant_key', $key);$variation->update_meta_data('_dallasss_source_price_toman', $variant['source_price_toman']);
    return $variation;
}, 10, 2);
add_filter('woocommerce_is_purchasable', __NAMESPACE__ . '\\can_purchase', 10, 2);
add_filter('woocommerce_variation_is_purchasable', __NAMESPACE__ . '\\can_purchase', 10, 2);
function can_purchase(bool $allowed, $product): bool {
    $p = product_payload($product);if (!$p) { return $allowed; }
    $parent = $product->is_type('variation') ? $product->get_parent_id() : $product->get_id();
    if (!settings()['direct_enabled'] || !fresh($p) || get_post_meta($parent, '_dallasss_sync_state', true) === 'updating' || !in_array($p['source'], settings()['approved_sources'], true)) { return false; }
    return $allowed;
}
foreach (['woocommerce_product_get_stock_status', 'woocommerce_product_variation_get_stock_status'] as $hook) {
    add_filter($hook, function ($status, $product) { $p = product_payload($product);return $p && !fresh($p) ? 'outofstock' : $status; }, 10, 2);
}
add_action('dallasss_maintenance', function () {
    global $wpdb;
    $cutoff = gmdate('Y-m-d H:i:s', time() - settings()['fresh_minutes'] * 60);
    $ids = $wpdb->get_col($wpdb->prepare("SELECT o.product_id FROM {$wpdb->prefix}dallasss_offers o INNER JOIN {$wpdb->postmeta} m ON o.product_id=m.post_id AND m.meta_key='_stock_status' AND m.meta_value='instock' WHERE o.observed_at < %s ORDER BY o.id LIMIT 40", $cutoff));
    foreach ($ids as $id) {
        $product = wc_get_product($id);if (!$product) { continue; }
        foreach ($product->get_children() as $child_id) { $child = wc_get_product($child_id);if ($child && $child->get_stock_quantity() > 0) { wc_update_product_stock($child, 0, 'set'); } }
        \WC_Product_Variable::sync($id);
    }
    $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->prefix}dallasss_price_history WHERE observed_at < %s LIMIT 500", gmdate('Y-m-d H:i:s', time() - 180 * DAY_IN_SECONDS)));
    if (function_exists('as_enqueue_async_action')) {
        foreach ($wpdb->get_col("SELECT id FROM {$wpdb->prefix}dallasss_outbox WHERE state='pending' AND attempts<5 ORDER BY id LIMIT 10") as $event_id) { as_enqueue_async_action('dallasss_send_telegram', ['event_id' => (int) $event_id], 'dallasss', true); }
    }
});

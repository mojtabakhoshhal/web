<?php
namespace Dallasss;
defined('ABSPATH') || exit;
function admin_permission(): bool { return current_user_can('manage_woocommerce'); }
function api_product(int $id): ?array {
    $product = wc_get_product($id);$p = product_payload($product);
    if (!$product || !$product->is_type('variable') || !$p || $product->get_status() !== 'publish') { return null; }
    $sizes = [];$stock = 0;
    foreach ($product->get_children() as $child_id) {
        $child = wc_get_product($child_id);if (!$child) { continue; }
        $key = $child->get_meta('_dallasss_variant_key');
        foreach ($p['variants'] as $v) {
            if ($v['key'] !== $key) { continue; }
            $quantity = fresh($p) && settings()['direct_enabled'] && get_post_meta($id, '_dallasss_sync_state', true) !== 'updating' ? min(max(0, (int) $child->get_stock_quantity()), effective_stock($child_id, $v['quantity'])) : 0;
            $row = ['label' => $v['size'], 'stock' => $quantity, 'variation_id' => $child_id];
            foreach (['chest', 'waist', 'shoulder'] as $field) {
                if (isset($v['measurements_cm'][$field])) { $row[$field] = (float) $v['measurements_cm'][$field]; }
                elseif (isset($v['measurement_ranges_cm'][$field])) { $row[$field] = $v['measurement_ranges_cm'][$field]; }
            }
            $sizes[] = $row;$stock += $quantity;
        }
    }
    $drop_at = (int) get_post_meta($id, '_dallasss_drop_at', true);
    $old = $drop_at > time() - 48 * HOUR_IN_SECONDS ? (int) get_post_meta($id, '_dallasss_old_price_toman', true) : null;
    $names = ['basalam' => 'باسلام', 'vegas' => 'وگاس', 'verna' => 'ورنا', 'shopino' => 'شاپینو'];
    $price = $product->get_variation_price('min', false);
    $bnpl = !empty($p['bnpl']['verified']) && (int) ($p['bnpl']['count'] ?? 0) === 4 && !empty($p['bnpl']['affiliate_approved']);
    return ['id' => $id, 'title' => $product->get_name(), 'english' => $p['english_title'] ?? 'DALLASSS SELECTION', 'category' => $p['category'], 'price' => $price !== '' ? to_toman($price) : sell_price($p['source_price_toman']), 'oldPrice' => $old, 'source' => $p['source'], 'sourceName' => $names[$p['source']], 'sourceUrl' => $p['source_url'], 'image' => $p['images'][0], 'color' => $p['color'], 'colors' => [$p['color']], 'tags' => $p['tags'], 'occasions' => $p['occasions'], 'sizes' => $sizes, 'stock' => $stock, 'fit' => $p['fit'], 'bnpl' => $bnpl, 'installmentAmount' => $bnpl ? (int) $p['bnpl']['first_payment_toman'] : null, 'affiliateUrl' => $bnpl ? rest_url('dallasss/v1/go/' . $id) : null, 'drop' => $old > 0, 'demo' => false, 'reviewSummary' => $p['review_summary'] ?? null, 'observedAt' => $p['observed_at']];
}
function catalog_ids(int $limit = 100, int $offset = 0): array {
    global $wpdb;
    return $wpdb->get_col($wpdb->prepare("SELECT product_id FROM {$wpdb->prefix}dallasss_offers ORDER BY id DESC LIMIT %d OFFSET %d", $limit, $offset));
}
function torob_auth(\WP_REST_Request $request) {
    if (!function_exists('sodium_crypto_sign_verify_detached')) { return new \WP_Error('sodium_required', 'PHP Sodium is required.', ['status' => 503]); }
    $token = $request->get_header('x-torob-token');
    if ($request->get_header('x-torob-token-version') !== '1' || strlen($token) > 6000) { return new \WP_Error('invalid_token', 'Invalid token version.', ['status' => 401]); }
    $parts = explode('.', $token);if (count($parts) !== 3) { return new \WP_Error('invalid_token', 'Invalid token.', ['status' => 401]); }
    $decode = function ($s) { return base64_decode(strtr($s, '-_', '+/') . str_repeat('=', (4 - strlen($s) % 4) % 4), true); };
    $header = json_decode($decode($parts[0]) ?: '', true);$claims = json_decode($decode($parts[1]) ?: '', true);$sig = $decode($parts[2]);
    $key = base64_decode('MCowBQYDK2VwAyEAt6Mu4T0pBORY11W+QeM35UsmLO3vsf+6yKpFDEImFk0=', true);
    $host = wp_parse_url(home_url(), PHP_URL_HOST);$port = wp_parse_url(home_url(), PHP_URL_PORT);$aud = $host . ($port ? ':' . $port : '');
    if (!is_array($header) || ($header['alg'] ?? '') !== 'EdDSA' || (int) ($header['v'] ?? 0) !== 1 || !is_array($claims) || !is_int($claims['exp'] ?? null) || !is_int($claims['nbf'] ?? null) || $claims['exp'] <= time() || $claims['nbf'] > time() || ($claims['aud'] ?? '') !== $aud || !is_string($sig) || strlen($sig) !== 64) { return new \WP_Error('invalid_token', 'Token claims rejected.', ['status' => 401]); }
    if (!sodium_crypto_sign_verify_detached($sig, $parts[0] . '.' . $parts[1], substr($key, -32))) { return new \WP_Error('invalid_signature', 'Token signature rejected.', ['status' => 401]); }
    return true;
}
function feed_rows(array $ids): array {
    $rows = [];
    foreach ($ids as $id) {
        $product = wc_get_product($id);$p = api_product((int) $id);if (!$p || !$product) { continue; }
        $data = product_payload($product);
        $row = ['page_unique' => (string) $id, 'page_url' => get_permalink($id), 'product_group_id' => (string) $id, 'title' => $p['title'], 'current_price' => $p['stock'] > 0 ? $p['price'] : 0, 'availability' => $p['stock'] > 0, 'category_name' => $p['category'], 'image_links' => $data['images'], 'spec' => (object) ['color' => $p['color'], 'fit' => $p['fit']], 'date_added' => $product->get_date_created()->date('c'), 'date_updated' => $product->get_date_modified()->date('c')];
        if ($p['oldPrice'] > $p['price']) { $row['old_price'] = $p['oldPrice']; }
        $rows[] = $row;
    }
    return $rows;
}
function marketplace_feed(\WP_REST_Request $r) {
    global $wpdb;$table = $wpdb->prefix . 'dallasss_offers';$post = $r->get_method() === 'POST';
    $data = $post ? $r->get_json_params() : $r->get_query_params();$data = is_array($data) ? $data : [];
    $page = 1;$cursor = null;
    if ($post) {
        if (!array_intersect(array_keys($data), ['page_urls', 'page_uniques', 'page', 'sort', 'cursor'])) { return new \WP_Error('invalid_parameters', 'Explicit product selection or sort is required.', ['status' => 400]); }
        if (isset($data['page_urls']) || isset($data['page_uniques'])) {
            if (isset($data['page_urls']) && isset($data['page_uniques'])) { return new \WP_Error('invalid_parameters', 'Use one selection method.', ['status' => 400]); }
            $selection = $data['page_uniques'] ?? $data['page_urls'];
            if (!is_array($selection) || count($selection) < 1 || count($selection) > 100) { return new \WP_Error('invalid_parameters', 'Select 1 to 100 products.', ['status' => 400]); }
            $ids = isset($data['page_uniques']) ? array_map('absint', $selection) : array_map('url_to_postid', $selection);
            $total = count($ids);
        } else {
            $sort = $data['sort'] ?? null;
            if (!in_array($sort, ['date_added_desc', 'date_updated_desc', 'product_id_desc'], true)) { return new \WP_Error('invalid_sort', 'Unsupported sort.', ['status' => 400]); }
            if (isset($data['cursor']) && ($sort !== 'product_id_desc' || isset($data['page']) || !ctype_digit((string) $data['cursor']))) { return new \WP_Error('invalid_cursor', 'Invalid cursor parameters.', ['status' => 400]); }
            if (isset($data['cursor'])) { $cursor = (int) $data['cursor']; }
            $page = isset($data['page']) ? (int) $data['page'] : 1;
            if ($page < 1 || $page > 100000) { return new \WP_Error('invalid_page', 'Invalid page.', ['status' => 400]); }
            $sort_column = ['date_added_desc' => 'created_at', 'date_updated_desc' => 'updated_at', 'product_id_desc' => 'product_id'][$sort];
            $ids = $cursor !== null ? $wpdb->get_col($wpdb->prepare("SELECT product_id FROM $table WHERE product_id < %d ORDER BY product_id DESC LIMIT 100", $cursor)) : $wpdb->get_col($wpdb->prepare("SELECT product_id FROM $table ORDER BY $sort_column DESC,product_id DESC LIMIT 100 OFFSET %d", ($page - 1) * 100));
            $total = (int) $wpdb->get_var("SELECT COUNT(*) FROM $table");
        }
    } else {
        $page = max(1, (int) ($data['page'] ?? 1));$ids = catalog_ids(100, ($page - 1) * 100);$total = (int) $wpdb->get_var("SELECT COUNT(*) FROM $table");
    }
    $cache_key = 'feed:' . hash('sha256', wp_json_encode([$ids, get_option('dallasss_feed_revision', ''), intdiv(time(), 15)]));
    $rows = get_transient($cache_key);
    if ($rows === false) { $rows = feed_rows($ids);set_transient($cache_key, $rows, 20); }
    $result = ['api_version' => $post ? 'torob_api_v3' : 'dallasss_feed_v1', 'currency' => 'IRT', 'current_page' => $cursor === null ? $page : null, 'total' => $total, 'max_pages' => (int) ceil($total / 100), 'next_cursor' => count($ids) === 100 ? (string) end($ids) : null, 'products' => $rows];
    $response = new \WP_REST_Response($result);
    $response->header('Cache-Control', $post ? 'private, no-store' : 'public, max-age=10');
    $response->header('ETag', '"' . hash('sha256', wp_json_encode($result)) . '"');
    if ($r->get_header('if-none-match') === $response->get_headers()['ETag']) { $response->set_status(304);$response->set_data(null); }
    return $response;
}
function harmony(string $a, string $b): float {
    $hue = function ($h) {
        $c = array_map(fn($v) => hexdec($v) / 255, str_split(ltrim($h, '#'), 2));$max = max($c);$min = min($c);$d = $max - $min;
        if ($d < .12) { return null; }
        $n = $max === $c[0] ? ($c[1] - $c[2]) / $d : ($max === $c[1] ? ($c[2] - $c[0]) / $d + 2 : ($c[0] - $c[1]) / $d + 4);
        return fmod($n * 60 + 360, 360);
    };
    $x = $hue($a);$y = $hue($b);if ($x === null || $y === null) { return 1; }$d = min(abs($x - $y), 360 - abs($x - $y));return $d < 40 || $d > 145 ? .95 : .45;
}
function outfit(\WP_REST_Request $r) {
    $anchor = api_product((int) $r['product_id']);$budget = (int) $r['budget'];
    if (!$anchor || $anchor['stock'] <= 0 || $budget < 1 || $budget > 100000000) { return new \WP_Error('invalid_anchor', 'Choose an in-stock garment and valid budget.', ['status' => 422]); }
    $categories = ['Top', 'Bottom', 'Footwear'];$needed = array_values(array_diff($categories, [$anchor['category']]));
    if (count($needed) !== 2) { return new \WP_Error('invalid_category', 'Outfit anchor must be Top, Bottom or Footwear.', ['status' => 422]); }
    $all = array_values(array_filter(array_map(__NAMESPACE__ . '\\api_product', catalog_ids(80))));$pools = [[], []];$occasion = sanitize_key($r['occasion'] ?? 'all');
    foreach ($all as $p) { if ($p['source'] === $anchor['source'] || $p['stock'] <= 0 || ($occasion !== 'all' && !in_array($occasion, $p['occasions'], true))) { continue; }$i = array_search($p['category'], $needed, true);if ($i !== false) { $pools[$i][] = $p; } }
    $matches = [];
    foreach ($pools[0] as $a) { foreach ($pools[1] as $b) {
        $total = $anchor['price'] + $a['price'] + $b['price'];if ($a['source'] === $b['source'] || $total > $budget) { continue; }
        $items = [$anchor, $a, $b];usort($items, fn($x, $y) => array_search($x['category'], $categories, true) <=> array_search($y['category'], $categories, true));
        $matches[] = ['items' => $items, 'total' => $total, 'score' => harmony($anchor['color'], $a['color']) + harmony($anchor['color'], $b['color']) + .3 * count(array_intersect($anchor['tags'], $a['tags'])) + .3 * count(array_intersect($anchor['tags'], $b['tags']))];
    } }
    usort($matches, fn($a, $b) => $b['score'] <=> $a['score'] ?: $a['total'] <=> $b['total']);
    return $matches ? $matches[abs((int) ($r['seed'] ?? 0)) % min(5, count($matches))] : ['items' => null, 'reason' => 'No eligible combination within budget.'];
}
function add_cart(\WP_REST_Request $r) {
    if (!wp_verify_nonce($r->get_header('x-wp-nonce'), 'wp_rest')) { return new \WP_Error('invalid_nonce', 'Refresh the page and try again.', ['status' => 403]); }
    $origin = $r->get_header('origin');$home = wp_parse_url(home_url());$expected = $home['scheme'] . '://' . $home['host'] . (isset($home['port']) ? ':' . $home['port'] : '');
    if ($origin && $origin !== $expected) { return new \WP_Error('invalid_origin', 'Same-origin requests only.', ['status' => 403]); }
    $items = $r->get_param('items');if (!is_array($items) || count($items) < 1 || count($items) > 20) { return new \WP_Error('invalid_cart', 'One to twenty lines required.', ['status' => 422]); }
    if (!WC()->cart) { wc_load_cart(); }
    $validated = [];
    foreach ($items as $item) {
        $p = api_product((int) ($item['product_id'] ?? 0));$quantity = (int) ($item['quantity'] ?? 0);$choice = null;
        if ($p && strtolower($item['color'] ?? '') === strtolower($p['color'])) { foreach ($p['sizes'] as $size) { if ($size['label'] === ($item['size'] ?? '')) { $choice = $size;break; } } }
        if (!$choice || $quantity < 1 || $quantity > 20 || $choice['stock'] < $quantity) { return new \WP_Error('stock_changed', 'Price or size availability changed. Refresh the selection.', ['status' => 409]); }
        $validated[] = ['parent' => $p['id'], 'variation' => $choice['variation_id'], 'quantity' => $quantity, 'size' => $choice['label']];
    }
    $backup = WC()->cart->get_cart();WC()->cart->empty_cart(false);
    try {
        foreach ($validated as $v) { if (!WC()->cart->add_to_cart($v['parent'], $v['quantity'], $v['variation'], ['attribute_size' => $v['size']])) { throw new \RuntimeException('A garment can no longer be added.'); } }
        WC()->session->set('dallasss_bundle_ids', array_map('absint', (array) $r->get_param('bundle')));
        WC()->cart->calculate_totals();
    } catch (\Throwable $e) {
        WC()->cart->empty_cart(false);
        foreach ($backup as $line) { WC()->cart->add_to_cart($line['product_id'], $line['quantity'], $line['variation_id'], $line['variation']); }
        return new \WP_Error('cart_failed', $e->getMessage(), ['status' => 409]);
    }
    return ['checkout_url' => wc_get_checkout_url()];
}
add_action('rest_api_init', function () {
    register_rest_route('dallasss/v1', '/catalog', ['methods' => 'GET', 'permission_callback' => '__return_true', 'callback' => function ($r) { $limit = max(1, min(60, (int) ($r['per_page'] ?? 60)));$page = max(1, (int) ($r['page'] ?? 1));return ['products' => array_values(array_filter(array_map(__NAMESPACE__ . '\\api_product', catalog_ids($limit, ($page - 1) * $limit))))]; }]);
    register_rest_route('dallasss/v1', '/match-outfit', ['methods' => 'GET', 'permission_callback' => '__return_true', 'callback' => __NAMESPACE__ . '\\outfit']);
    register_rest_route('dallasss/v1', '/cart/add', ['methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => __NAMESPACE__ . '\\add_cart']);
    register_rest_route('dallasss/v1', '/marketplace-feed', [
        ['methods' => 'GET', 'permission_callback' => '__return_true', 'callback' => __NAMESPACE__ . '\\marketplace_feed'],
        ['methods' => 'POST', 'permission_callback' => __NAMESPACE__ . '\\torob_auth', 'callback' => __NAMESPACE__ . '\\marketplace_feed'],
    ]);
    register_rest_route('dallasss/v1', '/sync/catalog', ['methods' => 'GET', 'permission_callback' => __NAMESPACE__ . '\\admin_permission', 'callback' => function ($r) {
        global $wpdb;$after = max(0, (int) ($r['after'] ?? 0));$rows = $wpdb->get_results($wpdb->prepare("SELECT id,product_id,payload FROM {$wpdb->prefix}dallasss_offers WHERE id>%d ORDER BY id LIMIT 100", $after), ARRAY_A);
        return ['items' => array_map(fn($row) => ['cursor' => (int) $row['id'], 'product_id' => (int) $row['product_id'], 'payload' => json_decode($row['payload'], true)], $rows), 'next_cursor' => count($rows) === 100 ? (int) end($rows)['id'] : null];
    }]);
    register_rest_route('dallasss/v1', '/sync/stock-export', ['methods' => 'GET', 'permission_callback' => __NAMESPACE__ . '\\admin_permission', 'callback' => function ($r) {
        $s = settings();if (!$s['digikala_enabled'] || !$s['digikala_currency']) { return new \WP_Error('not_configured', 'Verify seller access and price currency before export.', ['status' => 409]); }
        global $wpdb;$after = max(0, (int) ($r['after'] ?? 0));$parents = $wpdb->get_results($wpdb->prepare("SELECT id,product_id FROM {$wpdb->prefix}dallasss_offers WHERE id>%d ORDER BY id LIMIT 40", $after), ARRAY_A);
        $rows = [];
        foreach ($parents as $parent) { $id = (int) $parent['product_id'];$p = api_product($id);if (!$p) { continue; }foreach ($p['sizes'] as $size) {
            $v = wc_get_product($size['variation_id']);$dk = (int) $v->get_meta('_dallasss_digikala_variant_id');if (!$dk) { continue; }
            $rows[] = ['variant_id' => $dk, 'source_url' => $p['sourceUrl'], 'sku' => $v->get_sku(), 'size' => $size['label'], 'selling_price_toman' => to_toman($v->get_price()), 'stock' => $size['stock'], 'api_currency' => $s['digikala_currency'], 'observed_at' => $p['observedAt']];
        } }
        return ['items' => $rows, 'next_cursor' => count($parents) === 40 ? (int) end($parents)['id'] : null];
    }]);
    register_rest_route('dallasss/v1', '/go/(?P<id>\d+)', ['methods' => 'GET', 'permission_callback' => '__return_true', 'callback' => function ($r) {
        $p = product_payload(wc_get_product((int) $r['id']));$url = $p['bnpl']['affiliate_url'] ?? '';
        if (empty($p['bnpl']['affiliate_approved']) || !public_https($url, settings()['source_hosts'][$p['source'] ?? ''] ?? [])) { return new \WP_Error('affiliate_unavailable', 'No approved affiliate link.', ['status' => 404]); }
        nocache_headers();header('Referrer-Policy: no-referrer');wp_redirect($url, 302, 'Dallasss');exit;
    }]);
});
add_filter('rest_pre_serve_request', function ($served, $result, $request) {
    if ($request->get_route() !== '/dallasss/v1/marketplace-feed' || $request->get_method() !== 'GET' || $request['format'] !== 'xml' || $result->get_status() !== 200) { return $served; }
    header('Content-Type: application/xml; charset=UTF-8');$xml = new \XMLWriter();$xml->openMemory();$xml->startDocument('1.0', 'UTF-8');$xml->startElement('dallasss_feed');$xml->writeAttribute('currency', 'IRT');
    foreach ($result->get_data()['products'] as $row) { $xml->startElement('product');foreach ($row as $key => $value) { if (is_scalar($value)) { $xml->writeElement($key, is_bool($value) ? ($value ? 'true' : 'false') : (string) $value); }elseif ($key === 'image_links') { foreach ($value as $url) { $xml->writeElement('image', $url); } } }$xml->endElement(); }
    $xml->endElement();$xml->endDocument();echo $xml->outputMemory();return true;
}, 10, 3);

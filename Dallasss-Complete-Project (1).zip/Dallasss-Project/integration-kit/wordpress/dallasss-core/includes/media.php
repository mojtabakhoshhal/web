<?php
namespace Dallasss;
defined('ABSPATH') || exit;
function remote_url(int $id): string {
    $url = (string) get_post_meta($id, '_dallasss_remote_url', true);
    return public_https($url, settings()['image_hosts']) ? $url : '';
}
add_filter('wp_get_attachment_url', function ($url, $id) { return remote_url((int) $id) ?: $url; }, 10, 2);
add_filter('image_downsize', function ($result, $id) { $url = remote_url((int) $id);return $url ? [$url, 0, 0, false] : $result; }, 10, 2);
add_filter('wp_calculate_image_srcset', function ($sources, $size, $src, $meta, $id) { return remote_url((int) $id) ? false : $sources; }, 10, 5);
add_filter('wp_get_attachment_image', function ($html, $id) { return remote_url((int) $id) ? preg_replace('/\s(?:width|height)="0"/', '', $html) : $html; }, 10, 2);
add_filter('woocommerce_product_get_image', function ($html, $product) {
    $payload = product_payload($product);
    $url = $payload['images'][0] ?? '';
    if (!public_https($url, settings()['image_hosts'])) { return $html; }
    return '<img class="dallasss-remote-image" src="' . esc_url($url) . '" alt="' . esc_attr($product->get_name()) . '" loading="lazy" decoding="async" referrerpolicy="no-referrer">';
}, 10, 2);
function assign_remote_image(\WC_Product $product, array $payload): void {
    $url = $payload['images'][0] ?? '';
    if (!public_https($url, settings()['image_hosts'])) { return; }
    $attachment_id = (int) get_post_meta($product->get_id(), '_dallasss_remote_attachment_id', true);
    if (!$attachment_id || get_post_type($attachment_id) !== 'attachment') {
        $attachment_id = wp_insert_post(['post_type' => 'attachment', 'post_status' => 'inherit', 'post_parent' => $product->get_id(), 'post_title' => $product->get_name(), 'post_mime_type' => 'image/jpeg'], true);
        if (is_wp_error($attachment_id)) { return; }
        update_post_meta($product->get_id(), '_dallasss_remote_attachment_id', $attachment_id);
    }
    update_post_meta($attachment_id, '_dallasss_remote_url', $url);
    update_post_meta($attachment_id, '_wp_attachment_image_alt', $product->get_name());
    $product->set_image_id($attachment_id);$product->save();
}

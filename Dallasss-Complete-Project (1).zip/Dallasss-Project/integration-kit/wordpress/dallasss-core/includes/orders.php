<?php
namespace Dallasss;
defined('ABSPATH') || exit;
add_action('woocommerce_checkout_create_order_line_item', function ($item, $cart_key, $values) {
    $product = $values['data'];$p = product_payload($product);if (!$p) { return; }
    $item->add_meta_data('_dallasss_source_url', $p['source_url'], true);
    $item->add_meta_data('_dallasss_source', $p['source'], true);
    $item->add_meta_data('_dallasss_source_cost_toman', (int) $product->get_meta('_dallasss_source_price_toman'), true);
    $item->add_meta_data('_dallasss_shipping_buffer_toman', settings()['shipping_buffer'], true);
    $item->add_meta_data('_dallasss_variant_key', $product->get_meta('_dallasss_variant_key'), true);
}, 10, 3);
function reserve_order($order): void {
    if (is_numeric($order)) { $order = wc_get_order($order); }if (!$order) { return; }
    global $wpdb;
    foreach ($order->get_items() as $item) {
        if (!$item->get_meta('_dallasss_source_url')) { continue; }
        $wpdb->query($wpdb->prepare("INSERT IGNORE INTO {$wpdb->prefix}dallasss_reservations (order_item_id,order_id,variation_id,quantity,state,created_at) VALUES (%d,%d,%d,%d,'held',%s)", $item->get_id(), $order->get_id(), $item->get_variation_id(), $item->get_quantity(), gmdate('Y-m-d H:i:s')));
    }
    update_option('dallasss_feed_revision', microtime(true), false);
}
add_action('woocommerce_checkout_order_created', __NAMESPACE__ . '\\reserve_order');
add_action('woocommerce_store_api_checkout_order_processed', __NAMESPACE__ . '\\reserve_order');
add_action('woocommerce_order_status_cancelled', function ($id) {
    $order = wc_get_order($id);if (!$order || $order->get_date_paid()) { return; }
    global $wpdb;$wpdb->update($wpdb->prefix . 'dallasss_reservations', ['state' => 'released'], ['order_id' => $id]);
});
add_filter('woocommerce_order_actions', function ($actions) { $actions['dallasss_reconcile_source'] = 'Dallasss: supplier purchased and inventory reconciled';return $actions; });
add_action('woocommerce_order_action_dallasss_reconcile_source', function ($order) {
    if (!current_user_can('manage_woocommerce')) { return; }
    global $wpdb;$wpdb->update($wpdb->prefix . 'dallasss_reservations', ['state' => 'reconciled'], ['order_id' => $order->get_id()]);
    $order->add_order_note('Supplier purchase and inventory reconciliation confirmed by administrator. Stock may be replenished only by a subsequent verified supplier quote.');
});
add_action('woocommerce_cart_calculate_fees', function ($cart) {
    if (is_admin() && !wp_doing_ajax()) { return; }
    if (!WC()->session || !$cart || $cart->is_empty()) { return; }
    $ids = array_values(array_unique(array_map('absint', WC()->session->get('dallasss_bundle_ids', []))));
    if (count($ids) !== 3) { return; }
    $sources = [];$categories = [];$subtotal = 0;$cost = 0;
    foreach ($cart->get_cart() as $line) {
        if (!in_array($line['product_id'], $ids, true) || $line['quantity'] !== 1) { return; }
        $p = product_payload($line['data']);if (!$p || !fresh($p)) { return; }
        $sources[] = $p['source'];$categories[] = $p['category'];$subtotal += (float) $line['line_total'];
        $cost += from_toman((int) $line['data']->get_meta('_dallasss_source_price_toman') + settings()['shipping_buffer']);
    }
    sort($categories);
    if (count($cart->get_cart()) !== 3 || count(array_unique($sources)) !== 3 || $categories !== ['Bottom', 'Footwear', 'Top']) { return; }
    $discount = min(floor($subtotal * settings()['bundle_percent'] / 100), max(0, $subtotal - $cost));
    if ($discount > 0) { $cart->add_fee('تخفیف ست دالاس', -$discount, false); }
});
function queue_paid_order($id): void {
    $order = wc_get_order($id);if (!$order || !$order->is_paid()) { return; }
    $relevant = false;foreach ($order->get_items() as $item) { if ($item->get_meta('_dallasss_source_url')) { $relevant = true;break; } }if (!$relevant) { return; }
    reserve_order($order);queue_event('wc:' . $id, $id, []);
}
function queue_event(string $key, int $order_id, array $payload): void {
    global $wpdb;$now = gmdate('Y-m-d H:i:s');
    $wpdb->query($wpdb->prepare("INSERT IGNORE INTO {$wpdb->prefix}dallasss_outbox (event_key,order_id,payload,state,created_at,updated_at) VALUES (%s,%d,%s,'pending',%s,%s)", $key, $order_id, wp_json_encode($payload), $now, $now));
    $event = $wpdb->get_row($wpdb->prepare("SELECT id,state FROM {$wpdb->prefix}dallasss_outbox WHERE event_key=%s", $key));
    if ($event && $event->state === 'pending' && function_exists('as_enqueue_async_action')) { as_enqueue_async_action('dallasss_send_telegram', ['event_id' => (int) $event->id], 'dallasss', true); }
}
add_action('woocommerce_payment_complete', __NAMESPACE__ . '\\queue_paid_order');
add_action('woocommerce_order_status_processing', __NAMESPACE__ . '\\queue_paid_order');
add_action('woocommerce_order_status_completed', __NAMESPACE__ . '\\queue_paid_order');
add_action('woocommerce_thankyou', __NAMESPACE__ . '\\queue_paid_order');
function html_message($value): string { return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function order_message(\WC_Order $order): string {
    $name = trim($order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name()) ?: $order->get_formatted_billing_full_name();
    $address = $order->get_shipping_address_1() ? implode('، ', array_filter([$order->get_shipping_state(), $order->get_shipping_city(), $order->get_shipping_address_1(), $order->get_shipping_address_2()])) : implode('، ', array_filter([$order->get_billing_state(), $order->get_billing_city(), $order->get_billing_address_1(), $order->get_billing_address_2()]));
    $msg = '<b>سفارش پرداخت‌شدهٔ دالاس #' . html_message($order->get_order_number()) . '</b>' . "\n";
    $msg .= 'نام: ' . html_message($name) . "\n" . 'نشانی: ' . html_message($address) . "\n" . 'تلفن: ' . html_message($order->get_billing_phone()) . "\n" . 'کدپستی: ' . html_message($order->get_shipping_postcode() ?: $order->get_billing_postcode()) . "\n\n";
    $margin = 0;
    foreach ($order->get_items() as $item) {
        $url = $item->get_meta('_dallasss_source_url');if (!$url) { continue; }
        $source = $item->get_meta('_dallasss_source');
        if (!public_https($url, settings()['source_hosts'][$source] ?? [])) { continue; }
        $margin += to_toman($item->get_total()) - ((int) $item->get_meta('_dallasss_source_cost_toman') + (int) $item->get_meta('_dallasss_shipping_buffer_toman')) * $item->get_quantity();
        $msg .= html_message($item->get_name()) . ' × ' . $item->get_quantity() . "\n" . 'سایز: ' . html_message($item->get_meta('Size') ?: $item->get_meta('size')) . "\n" . '<a href="' . html_message($url) . '">خرید از منبع</a>' . "\n\n";
    }
    foreach ($order->get_fees() as $fee) { $margin += to_toman($fee->get_total()); }
    $msg .= 'حاشیهٔ ناخالص برآوردی: ' . number_format($margin) . " تومان\n(پیش از کارمزدها و هزینه‌های نهایی)\n";
    return $msg . '<a href="' . html_message($order->get_edit_order_url()) . '">مدیریت سفارش</a>';
}
add_action('dallasss_send_telegram', function ($event_id) {
    if (!defined('DALLASSS_TELEGRAM_BOT_TOKEN') || !defined('DALLASSS_TELEGRAM_CHAT_ID') || !DALLASSS_TELEGRAM_BOT_TOKEN || !DALLASSS_TELEGRAM_CHAT_ID) { return; }
    global $wpdb;$table = $wpdb->prefix . 'dallasss_outbox';
    $changed = $wpdb->query($wpdb->prepare("UPDATE $table SET state='sending',attempts=attempts+1,updated_at=%s WHERE id=%d AND state='pending' AND attempts<5", gmdate('Y-m-d H:i:s'), $event_id));if ($changed !== 1) { return; }
    $event = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id=%d", $event_id));
    $order = $event->order_id ? wc_get_order($event->order_id) : null;
    if ($event->order_id && (!$order || !$order->is_paid())) { $wpdb->update($table, ['state' => 'cancelled'], ['id' => $event_id]);return; }
    $payload = json_decode($event->payload, true);$message = $order ? order_message($order) : ($payload['message'] ?? '');
    if ($message === '' || mb_strlen($message) > 3800) { $wpdb->update($table, ['state' => 'review_required'], ['id' => $event_id]);return; }
    $response = wp_remote_post('https://api.telegram.org/bot' . DALLASSS_TELEGRAM_BOT_TOKEN . '/sendMessage', ['timeout' => 20, 'redirection' => 0, 'headers' => ['Content-Type' => 'application/json'], 'body' => wp_json_encode(['chat_id' => (string) DALLASSS_TELEGRAM_CHAT_ID, 'text' => $message, 'parse_mode' => 'HTML', 'disable_web_page_preview' => true])]);
    $body = !is_wp_error($response) ? json_decode(wp_remote_retrieve_body($response), true) : [];
    $state = !empty($body['ok']) ? 'sent' : 'review_required';
    if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 429) {
        $state = 'pending';$delay = max(30, min(3600, (int) ($body['parameters']['retry_after'] ?? 60)));
        if (function_exists('as_schedule_single_action')) { as_schedule_single_action(time() + $delay, 'dallasss_send_telegram', ['event_id' => (int) $event_id], 'dallasss', true); }
    }
    $wpdb->update($table, ['state' => $state, 'updated_at' => gmdate('Y-m-d H:i:s')], ['id' => $event_id]);
    if ($state === 'review_required' && $order) { $order->add_order_note('Telegram delivery is unconfirmed. Review the order and bot history before retrying.'); }
}, 10, 1);
add_action('rest_api_init', function () {
    register_rest_route('dallasss/v1', '/events/digikala', ['methods' => 'POST', 'permission_callback' => __NAMESPACE__ . '\\admin_permission', 'callback' => function ($r) {
        $p = $r->get_json_params();$shipment = sanitize_text_field($p['shipment_id'] ?? '');$customer = $p['customer'] ?? []; $items = $p['items'] ?? [];
        if (!$shipment || !is_array($customer) || !is_array($items) || count($items) > 20 || count($items) < 1 || empty($customer['name']) || empty($customer['address']) || empty($customer['phone'])) { return new \WP_Error('invalid_relay', 'Validated seller-order relay schema is required.', ['status' => 422]); }
        $msg = '<b>سفارش دیجی‌کالا / محمولهٔ ' . html_message($shipment) . "</b>\n";
        foreach (['name' => 'نام', 'address' => 'نشانی', 'phone' => 'تلفن', 'postal_code' => 'کدپستی'] as $key => $label) { $msg .= $label . ': ' . html_message($customer[$key] ?? '') . "\n"; }
        foreach ($items as $item) {
            $variant_id = absint($item['variant_id'] ?? 0);
            $found = wc_get_products(['type' => 'variation', 'limit' => 1, 'meta_key' => '_dallasss_digikala_variant_id', 'meta_value' => $variant_id]);
            if (!$found) { return new \WP_Error('unmapped_variant', 'Map every seller variant before fulfillment.', ['status' => 409]); }
            $v = $found[0];$q = max(1, min(20, (int) ($item['quantity'] ?? 1)));$payload = product_payload($v);
            $msg .= "\n" . html_message($v->get_name()) . ' × ' . $q . "\nسایز: " . html_message($v->get_attribute('Size')) . "\n" . '<a href="' . html_message($payload['source_url']) . '">خرید از منبع</a>' . "\n";
        }
        $msg .= "\nتسویه و کارمزدها را در پنل فروشنده بررسی کنید.";
        queue_event('digikala:' . $shipment, 0, ['message' => $msg]);return ['accepted' => true];
    }]);
});

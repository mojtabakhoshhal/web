<?php
namespace Dallasss;
defined('ABSPATH') || exit;
function activate(): void {
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $charset = $wpdb->get_charset_collate();
    $prefix = $wpdb->prefix . 'dallasss_';
    dbDelta("CREATE TABLE {$prefix}offers (
        id bigint unsigned NOT NULL AUTO_INCREMENT,
        source_hash char(32) NOT NULL,
        source varchar(24) NOT NULL,
        source_id varchar(191) NOT NULL,
        product_id bigint unsigned NOT NULL,
        source_price_toman bigint unsigned NOT NULL DEFAULT 0,
        selling_price_toman bigint unsigned NOT NULL DEFAULT 0,
        observed_at datetime NOT NULL,
        payload longtext NOT NULL,
        created_at datetime NOT NULL,
        updated_at datetime NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY source_hash (source_hash),
        UNIQUE KEY product_id (product_id),
        KEY freshness (observed_at),
        KEY source_cursor (source,id)
    ) $charset;");
    dbDelta("CREATE TABLE {$prefix}price_history (
        id bigint unsigned NOT NULL AUTO_INCREMENT,
        source_hash char(32) NOT NULL,
        source_price_toman bigint unsigned NOT NULL,
        selling_price_toman bigint unsigned NOT NULL,
        observed_at datetime NOT NULL,
        observation_key char(64) NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY observation_key (observation_key),
        KEY history_lookup (source_hash,observed_at)
    ) $charset;");
    dbDelta("CREATE TABLE {$prefix}reservations (
        id bigint unsigned NOT NULL AUTO_INCREMENT,
        order_item_id bigint unsigned NOT NULL,
        order_id bigint unsigned NOT NULL,
        variation_id bigint unsigned NOT NULL,
        quantity int unsigned NOT NULL,
        state varchar(20) NOT NULL DEFAULT 'held',
        created_at datetime NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY order_item_id (order_item_id),
        KEY variation_state (variation_id,state),
        KEY order_id (order_id)
    ) $charset;");
    dbDelta("CREATE TABLE {$prefix}outbox (
        id bigint unsigned NOT NULL AUTO_INCREMENT,
        event_key varchar(191) NOT NULL,
        order_id bigint unsigned NOT NULL DEFAULT 0,
        payload longtext NOT NULL,
        state varchar(20) NOT NULL DEFAULT 'pending',
        attempts int unsigned NOT NULL DEFAULT 0,
        created_at datetime NOT NULL,
        updated_at datetime NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY event_key (event_key),
        KEY queue (state,updated_at)
    ) $charset;");
    if (!wp_next_scheduled('dallasss_maintenance')) { wp_schedule_event(time() + 60, 'hourly', 'dallasss_maintenance'); }
    update_option('dallasss_schema_version', 1, false);
}
function settings(): array {
    return wp_parse_args(get_option('dallasss_settings', []), [
        'markup_bps' => 3500, 'shipping_buffer' => 0, 'rounding' => 1,
        'fresh_minutes' => 150, 'safety_stock' => 1, 'direct_enabled' => 0,
        'bundle_percent' => 0, 'approved_sources' => [],
        'source_hosts' => ['basalam' => ['basalam.com'], 'verna' => ['verna.ir'], 'shopino' => ['shopino.app'], 'vegas' => []],
        'image_hosts' => [], 'digikala_enabled' => 0, 'digikala_currency' => '',
    ]);
}
function sell_price(int $source): int {
    $s = settings();
    $raw = intdiv($source * (10000 + (int) $s['markup_bps']) + 9999, 10000) + (int) $s['shipping_buffer'];
    $step = max(1, (int) $s['rounding']);
    return intdiv($raw + $step - 1, $step) * $step;
}
function to_toman($amount): int {
    return (int) round((float) $amount / (get_woocommerce_currency() === 'IRR' ? 10 : 1));
}
function from_toman(int $amount): int { return $amount * (get_woocommerce_currency() === 'IRR' ? 10 : 1); }
function fresh(array $payload): bool {
    $at = strtotime($payload['observed_at'] ?? '');
    return $at !== false && $at <= time() + 60 && $at >= time() - (int) settings()['fresh_minutes'] * 60;
}
function public_https(string $url, array $hosts): bool {
    $parts = wp_parse_url($url);
    if (!$parts || ($parts['scheme'] ?? '') !== 'https' || isset($parts['user']) || isset($parts['pass']) || (isset($parts['port']) && (int) $parts['port'] !== 443)) { return false; }
    $host = strtolower($parts['host'] ?? '');
    return in_array($host, array_map('strtolower', $hosts), true) && !filter_var($host, FILTER_VALIDATE_IP);
}
function product_payload($product): array {
    if (!$product) { return []; }
    $id = $product->is_type('variation') ? $product->get_parent_id() : $product->get_id();
    $value = get_post_meta($id, '_dallasss_payload', true);
    return is_array($value) ? $value : [];
}
function effective_stock(int $variation_id, ?int $source_stock): int {
    if ($source_stock === null) { return 0; }
    global $wpdb;
    $held = (int) $wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(quantity),0) FROM {$wpdb->prefix}dallasss_reservations WHERE variation_id=%d AND state='held'", $variation_id));
    return max(0, $source_stock - (int) settings()['safety_stock'] - $held);
}

<?php
namespace Dallasss;
defined('ABSPATH') || exit;
add_action('admin_menu', function () { add_options_page('Dallasss', 'Dallasss', 'manage_options', 'dallasss', __NAMESPACE__ . '\\settings_page'); });
add_action('admin_init', function () {
    register_setting('dallasss', 'dallasss_settings', ['type' => 'array', 'sanitize_callback' => function ($input) {
        $s = settings();
        foreach (['markup_bps' => [0, 10000], 'shipping_buffer' => [0, 10000000], 'rounding' => [1, 1000000], 'fresh_minutes' => [5, 180], 'safety_stock' => [0, 100], 'bundle_percent' => [0, 10]] as $key => $range) {
            $s[$key] = max($range[0], min($range[1], (int) ($input[$key] ?? $s[$key])));
        }
        foreach (['direct_enabled', 'digikala_enabled'] as $key) { $s[$key] = empty($input[$key]) ? 0 : 1; }
        $s['approved_sources'] = array_values(array_intersect(['basalam', 'vegas', 'verna', 'shopino'], (array) ($input['approved_sources'] ?? [])));
        foreach (['image_hosts', 'source_hosts'] as $key) {
            $value = json_decode(wp_unslash($input[$key] ?? '[]'), true);
            if (is_array($value)) { $s[$key] = $value; } else { add_settings_error('dallasss', $key, $key . ' must contain valid JSON.'); }
        }
        $s['digikala_currency'] = in_array($input['digikala_currency'] ?? '', ['IRR', 'IRT'], true) ? $input['digikala_currency'] : '';
        return $s;
    }]);
});
add_action('admin_init', function () {
    register_setting('dallasss', 'dallasss_vton', ['type' => 'array', 'sanitize_callback' => function ($input) {
        $space = sanitize_text_field($input['space'] ?? '');
        return ['enabled' => !empty($input['enabled']) && !empty($input['commercialUseAuthorized']) && (bool) preg_match('~^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$~', $space), 'commercialUseAuthorized' => !empty($input['commercialUseAuthorized']), 'space' => $space, 'apiName' => '/tryon'];
    }]);
});
function settings_page(): void {
    if (!current_user_can('manage_options')) { return; }
    $s = settings();
    echo '<div class="wrap"><h1>Dallasss Commerce</h1><p>Prices use integer Tomans. Keep direct sales disabled until supplier stock and payment are verified.</p><form method="post" action="options.php">';
    settings_fields('dallasss');
    echo '<table class="form-table">';
    foreach (['markup_bps' => 'Markup (basis points, 3500 = 35%)', 'shipping_buffer' => 'Additional pricing buffer (Toman; default 0)', 'rounding' => 'Round upward to (Toman; default 1)', 'fresh_minutes' => 'Maximum quote age (minutes)', 'safety_stock' => 'Supplier stock safety reserve', 'bundle_percent' => 'Optional bundle discount (default 0 to preserve 35% pricing)'] as $key => $label) {
        echo '<tr><th>' . esc_html($label) . '</th><td><input type="number" min="0" name="dallasss_settings[' . esc_attr($key) . ']" value="' . esc_attr($s[$key]) . '"></td></tr>';
    }
    foreach (['direct_enabled' => 'Enable verified direct sales', 'digikala_enabled' => 'Allow Digikala export'] as $key => $label) {
        echo '<tr><th>' . esc_html($label) . '</th><td><input type="checkbox" name="dallasss_settings[' . esc_attr($key) . ']" value="1" ' . checked($s[$key], 1, false) . '></td></tr>';
    }
    echo '<tr><th>Approved suppliers (permission obtained)</th><td>';
    foreach (['basalam', 'vegas', 'verna', 'shopino'] as $source) {
        echo '<label style="margin-right:20px"><input type="checkbox" name="dallasss_settings[approved_sources][]" value="' . esc_attr($source) . '" ' . checked(in_array($source, $s['approved_sources'], true), true, false) . '>' . esc_html($source) . '</label>';
    }
    echo '</td></tr>';
    foreach (['source_hosts', 'image_hosts'] as $key) {
        echo '<tr><th>' . esc_html($key) . ' (exact hostnames, JSON)</th><td><textarea rows="5" cols="80" name="dallasss_settings[' . esc_attr($key) . ']">' . esc_textarea(wp_json_encode($s[$key], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)) . '</textarea></td></tr>';
    }
    echo '<tr><th>Digikala API currency (confirm in seller account)</th><td><select name="dallasss_settings[digikala_currency]">';
    foreach (['' => 'Not verified; export blocked', 'IRR' => 'IRR / Rial', 'IRT' => 'IRT / Toman'] as $key => $label) { echo '<option value="' . esc_attr($key) . '" ' . selected($s['digikala_currency'], $key, false) . '>' . esc_html($label) . '</option>'; }
    echo '</select></td></tr></table>';
    $vton = get_option('dallasss_vton', []);
    echo '<h2>Optional, separately licensed photo fitting</h2><p><input type="text" name="dallasss_vton[space]" value="' . esc_attr($vton['space'] ?? '') . '"> Actual Hugging Face Space identifier</p>';
    foreach (['enabled' => 'Enable photo requests', 'commercialUseAuthorized' => 'Commercial use permission has been obtained and verified'] as $key => $label) { echo '<p><label><input type="checkbox" name="dallasss_vton[' . esc_attr($key) . ']" value="1" ' . checked(!empty($vton[$key]), true, false) . '>' . esc_html($label) . '</label></p>'; }
    submit_button();echo '</form><h2>Runtime</h2><pre>';
    echo esc_html(wp_json_encode(['php' => PHP_VERSION, 'memory_limit' => ini_get('memory_limit'), 'max_execution_time' => ini_get('max_execution_time'), 'upload_max_filesize' => ini_get('upload_max_filesize'), 'opcache' => function_exists('opcache_get_status') ? (bool) @opcache_get_status(false) : false, 'tables_prefix' => $GLOBALS['wpdb']->prefix, 'currency' => function_exists('get_woocommerce_currency') ? get_woocommerce_currency() : null], JSON_PRETTY_PRINT));
    echo '</pre><p>Shortcode: <code>[dallasss_storefront]</code>. Telegram credentials are server constants, never public JavaScript.</p></div>';
}

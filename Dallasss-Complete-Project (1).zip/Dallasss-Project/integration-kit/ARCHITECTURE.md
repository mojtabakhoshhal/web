# Dallasss architecture and contracts

Production target: one existing shared PHP host at `https://dallasss.ir`. The Sites deployment is an owner-private interactive preview, not a WordPress runtime and not a claimed deployment to that domain.

## Data flow

```mermaid
flowchart TD
  Runner["Scheduled Python runner"] --> Suppliers["Permitted supplier pages"]
  Runner --> Woo["WordPress and WooCommerce"]
  Runner --> Seller["Digikala Seller API"]
  Woo --> DB["Indexed MySQL tables"]
  Woo --> Browser["RTL storefront and SVG fitting"]
  Woo --> Feed["Approved marketplace feeds"]
  Woo --> Queue["Paid-order Telegram outbox"]
```

No Python, browser automation, image manipulation, inference, persistent Node process or external database runs on the shared host. The runner fetches observations in bounded jobs. Browser fitting is deterministic. Optional photo inference calls a separately authorized Gradio provider from the visitor's browser.

## Invariants

- Retail price is supplier price × 1.35. Default policy is 3500 basis points, zero additional buffer, rounding upward only to the next whole Toman, zero default bundle discount. Shipping is configured separately.
- All normalized monetary values are integer Tomans. WooCommerce may store IRT directly or IRR ×10. Seller API wire currency must be explicitly verified in the account before any write.
- Stable product hash: MD5 of UTF-8 `source + '|' + source_id`. Color estimates are never identity. A source identity represents one actual supplier color with size variants; ambiguous multicolor data is rejected.
- SKU, custom unique source_hash and repository concurrency are deduplication layers. A timed-out create is reconciled by SKU rather than blindly retried.
- `quantity:null` means unknown, not one, ten, available or zero at the supplier. Its direct sellable quantity is zero. A negative or fractional quantity is invalid.
- Availability expires after 150 minutes; clock skew beyond 60 seconds into the future is invalid. Crawling every two hours does not provide live supplier reservations.
- Sellable quantity is bounded by Woo's current stock and `max(0, supplier_quantity - safety_stock - outstanding_local_commitments)`. Unpaid cancellation releases a local commitment. Paid supplier purchases need operator inventory reconciliation before release.
- During a parent/variant import, the offer is not purchasable. Finalization verifies the observation identity and all expected sizes/prices. Removed sizes become unavailable.
- Purchase-time validation is authoritative. A displayed price, a client size suggestion, a thank-you visit, a Telegram message, and an affiliate redirect are not proof of stock, payment, fulfillment or earned profit.

## Normalized supplier observation

| Field | Type | Meaning |
|---|---|---|
| schema_version | integer | Currently 1 |
| source | enum | basalam / vegas / verna / shopino |
| source_id | nonempty string, max 191 bytes | Actual source SKU/product ID, or stable canonical URL digest |
| source_hash | 32-char hex | Stable MD5 identity |
| source_url | HTTPS URL | Canonical vendor product page; meaningful variant query parameters preserved |
| title | string | Supplier product name |
| source_price_toman | integer | Lowest concrete priced size offer; AggregateOffer lowPrice alone is rejected |
| images | 1–8 HTTPS URLs | Explicit allowlisted CDN hosts; no WordPress image sideload |
| color | 6-digit hex | Source hex, otherwise a clearly labeled center-crop estimate |
| color_method | enum | source_hex / center_crop_quantization |
| category | enum | Top / Bottom / Footwear / Accessory |
| tags | string array | Category and rule-derived Formal/Casual/Streetwear |
| occasions | string array | street / date / office |
| fit | enum | Slim / Regular / Oversized; source-title rule, not verified tailoring measurements |
| variants | 1–40 objects | key, source size, quantity or null, source_price_toman, measurements_cm, measurement_ranges_cm |
| variants[].measurements_cm | object | Physical chest/waist circumferences and shoulder width only when unambiguous |
| variants[].measurement_ranges_cm | object | `{field:{min,max}}`; source range preserved, not silently collapsed |
| observed_at | timezone-aware ISO 8601 | When the page was actually observed |
| review_summary | string or null | Scoped sample description, never an invented 94% buyer claim |
| review_evidence | object | Sample/fit mention counts and explicit_keyword_rules method; no personal reviewer data |
| ranking | enum or null | bestseller / mostviewed only for a verified listing URL |
| bnpl | object or null | Verified source installment amount and explicit affiliate approval; not derived from marked-up retail |

## Database

`database.sql` contains complete MySQL DDL using the default `wp_` prefix for inspection. Activation uses `$wpdb->prefix` and dbDelta, so existing custom prefixes are preserved. Core WooCommerce order APIs support HPOS; direct queries to legacy wp_posts orders are not used.

| Table suffix | Keys | Responsibility |
|---|---|---|
| dallasss_offers | Unique source_hash; unique product_id; observed_at index | Latest valid normalized quote and Woo parent mapping |
| dallasss_price_history | Unique observation_key; (source_hash, observed_at) | Actual source/retail price changes, 180-day bounded retention |
| dallasss_reservations | Unique order_item_id; (variation_id, state) | Outstanding local order commitments across source refreshes |
| dallasss_outbox | Unique event_key; (state, updated_at) | Paid-order notification identity, delivery status and bounded retries |

## HTTP contracts

| Route | Method/auth | Behavior |
|---|---|---|
| /wp-json/wc/v3/products/batch | POST / Woo API credentials | At most 20 total creates/updates/deletes; stable variable-parent SKUs |
| /wp-json/wc/v3/products/{id}/variations/batch | POST / Woo API credentials | At most 20 real source-size variations; server prices override client values |
| /wp-json/dallasss/v1/catalog | GET / public | Up to 60 recent parent cards per page; no supplier cost exposed |
| /wp-json/dallasss/v1/match-outfit | GET / public | Product_id, budget, occasion, seed; three categories and three suppliers, or explicit no-match |
| /wp-json/dallasss/v1/cart/add | POST / same-origin REST nonce | Validates actual color, size, exact quantity and fresh stock; server builds Woo cart |
| /wp-json/dallasss/v1/marketplace-feed | GET / public | Canonical Dallasss JSON; optional custom XML; integer IRT, explicit availability |
| Same route | POST / Torob signed JWT | Official Torob v3 shape, Ed25519 signature, audience, expiration and not-before checks |
| /wp-json/dallasss/v1/sync/catalog | GET / WP Application Password + manage_woocommerce | Cursor source index for delta observation |
| /wp-json/dallasss/v1/sync/policy | GET / same | Current authoritative retail policy and Woo currency |
| /wp-json/dallasss/v1/sync/finalize | POST / same | Makes a completely validated parent/variant import purchasable |
| /wp-json/dallasss/v1/sync/mapping | POST / same | Connects actual Woo variations to actual Digikala seller variants |
| /wp-json/dallasss/v1/sync/stock-export | GET / same | Approved, mapped seller price/stock updates; stale rows have stock zero |
| /wp-json/dallasss/v1/events/digikala | POST / same | Project-owned authenticated normalized order relay; not a fabricated native Digikala webhook |
| /wp-json/dallasss/v1/go/{id} | GET / public | Redirects only to an approved source affiliate URL |

## Failure handling and resource budget

Default catalog target is at most 160 source products, concurrency two, 40 size variants per product and 20 writes per REST batch. Reads have bounded backoff. Writes that might have committed are reconciled instead of blindly repeated. A failing import closes that parent until repaired. Expired source data becomes unavailable even before maintenance updates persisted stock.

The feed caches for a short interval with revision invalidation. It is not an event stream and cannot dictate the crawler frequency, ranking or product merge decision of another marketplace. Partner onboarding and current category policies remain external dependencies.

Actions have default-branch schedule semantics, queue delays, inactivity rules and plan limits. The provided job has a finite timeout and does not simulate a permanent free server. Budgeted shared hosting has host-controlled CPU, process and memory ceilings; WordPress constants cannot override them.

Telegram is queued after verified payment and exposes the requested customer shipping fields only to the configured administrator chat. Uncertain transport failures go to manual review. Delivery is not claimed to be mathematically exactly once; fulfillment and payment settlement remain separate operations.

## Unconnected dependencies

No real hosting account, DNS provider, seller token, Zarinpal merchant account, Telegram bot, supplier affiliate contract or commercial inference permission was provided to this execution. No live inventory writes, charges, customer messages or production domain changes were performed. Verified public protocols are implemented, but account-level acceptance testing remains required.

The source extractor is real standards-based code, including JSON-LD/XHR capture; four individually reverse-engineered, authenticated, live-tested supplier adapters are not claimed. Native Digikala order webhook/polling contracts were not invented. Its normalized relay can be connected once the actual seller account order shape is available.

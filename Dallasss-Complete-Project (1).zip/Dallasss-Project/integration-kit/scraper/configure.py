"""Interactive source configuration: actual user input, no guessed vendor routes."""
import json
from pathlib import Path
from urllib.parse import urlsplit

def url_lines(prompt):
    print(prompt + ' Enter one URL per line; a blank line finishes.')
    urls = []
    while True:
        value = input('HTTPS URL: ').strip()
        if not value: return urls
        p = urlsplit(value)
        if p.scheme != 'https' or not p.hostname or p.username or p.password:
            print('Use an actual HTTPS URL without credentials.');continue
        urls.append(value)

def main():
    config = {'max_products_per_source': 40, 'request_delay_seconds': 2, 'sources': []}
    defaults = {'basalam': 'basalam.com', 'vegas': None, 'verna': 'verna.ir', 'shopino': 'shopino.app'}
    for source, default in defaults.items():
        print('\nSOURCE:', source)
        enabled = input('Configure this source now? [yes/no]: ').strip().lower() == 'yes'
        if not enabled:
            config['sources'].append({'source': source, 'enabled': False, 'permission_confirmed': False});continue
        host = input(f'Confirmed exact store hostname{f" ({default})" if default else ""}: ').strip() or default
        if not host: raise SystemExit('Vegas identity is ambiguous. Supply the actual hostname before enabling it.')
        allowed = input('Do you have permission to use its catalog/images and respect its request limits? [yes/no]: ').strip().lower() == 'yes'
        if not allowed: raise SystemExit('This source remains disabled.')
        product_urls = url_lines('Supply actual product URLs for initial verification.')
        listings = url_lines('Supply verified bestseller/most-viewed men’s category URLs, if known.')
        ranking = input('Listing ranking [bestseller/mostviewed/none]: ').strip()
        if listings and ranking not in {'bestseller', 'mostviewed'}: raise SystemExit('Verify the listing sort before enabling discovery.')
        image_hosts = input('Exact permitted image CDN hostnames, comma-separated: ').strip().split(',')
        api_hosts = input('Additional permitted first-party XHR hostnames, comma-separated: ').strip().split(',')
        currency = input('Explicit fallback price unit [IRT/IRR]: ').strip().upper()
        if currency not in {'IRT', 'IRR'}: raise SystemExit('A verified price unit is required.')
        unit = input('Explicit size-table unit [cm/in/unknown]: ').strip()
        config['sources'].append({'source': source, 'enabled': True, 'permission_confirmed': True,
            'page_hosts': [host], 'api_hosts': [h.strip() for h in api_hosts if h.strip()],
            'image_hosts': [h.strip() for h in image_hosts if h.strip()], 'product_urls': product_urls,
            'listing_urls': listings, 'ranking': ranking if ranking != 'none' else None,
            'currency': currency, 'size_table_unit': unit if unit in {'cm', 'in'} else None})
    path = Path('config/sources.local.json');path.parent.mkdir(exist_ok=True)
    path.write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding='utf-8')
    print('Saved', path, '. Review before enabling scheduled runs. No credentials were stored.')

if __name__ == '__main__': main()

"""Official seller price/stock API integration; no invented catalog-creation endpoint."""
from __future__ import annotations
import argparse
import asyncio
import csv
import json
import os
from datetime import datetime, timezone
from pathlib import Path
import httpx
from openpyxl import load_workbook
from .sync import WooSync

BASE = 'https://seller.digikala.com/open-api/v1'

def wire_price(toman: int, currency: str) -> int:
    if currency not in {'IRT', 'IRR'}: raise ValueError('Confirm actual seller API currency before sending prices')
    if not isinstance(toman, int) or toman <= 0: raise ValueError('Positive integer Toman price required')
    return toman * (10 if currency == 'IRR' else 1)

class Seller:
    def __init__(self):
        token = os.getenv('DIGIKALA_TOKEN')
        if not token: raise ValueError('Set DIGIKALA_TOKEN using a seller-issued token with variant scope')
        self.http = httpx.AsyncClient(base_url=BASE, headers={'Authorization': 'Bearer ' + token}, timeout=30, follow_redirects=False)
    async def close(self): await self.http.aclose()
    async def request(self, method, path, body=None):
        # Absolute stock and price PATCH requests are idempotent; retries remain bounded.
        for attempt in range(4):
            r = await self.http.request(method, path, json=body)
            if 300 <= r.status_code < 400: raise ValueError('Unexpected authenticated API redirect')
            if r.status_code == 429 or r.status_code >= 500:
                if attempt == 3: r.raise_for_status()
                retry = r.headers.get('retry-after', '')
                await asyncio.sleep(min(30, int(retry)) if retry.isdigit() else 2 ** (attempt + 1));continue
            r.raise_for_status();result = r.json()
            if result.get('status') == 'error': raise ValueError('Seller rejected operation')
            return result
        raise RuntimeError('Seller retry budget exhausted')
    async def update(self, row):
        variant = int(row['variant_id']);desired = int(row['stock'])
        if not 0 <= desired <= 10000: raise ValueError('Invalid seller stock')
        observed = datetime.fromisoformat(row['observed_at'].replace('Z', '+00:00'))
        if observed.tzinfo is None or not -60 <= (datetime.now(timezone.utc)-observed).total_seconds() <= 150*60: desired = 0
        amount = wire_price(int(row['selling_price_toman']), row['api_currency'])
        # Close stock during price changes. If any intermediate operation fails, do not reopen it.
        await self.request('PATCH', f'/variants/{variant}/seller-stock', {'seller_stock': 0})
        await self.request('PATCH', '/variants/selling-price', {'variant_id': variant, 'selling_price': amount, 'credit_increase_percentage': 0})
        await self.request('PATCH', f'/variants/{variant}/seller-stock', {'seller_stock': desired})
        result = (await self.request('GET', f'/variants/{variant}'))['data']
        if int(result.get('marketplace_seller_stock', -1)) != desired or int(result.get('price_sale', -1)) != amount:
            await self.request('PATCH', f'/variants/{variant}/seller-stock', {'seller_stock': 0})
            raise ValueError('Seller read-back differs; stock set to zero for review')
        await asyncio.sleep(1.5)

def export_template(rows: list[dict], template: str, output: str, sheet: str | None, column_map: dict):
    """Fill the user's current category-specific seller template, preserving its workbook structure."""
    workbook = load_workbook(template);ws = workbook[sheet] if sheet else workbook.active
    header_row = int(column_map['header_row']);headers = {str(cell.value).strip(): cell.column for cell in ws[header_row] if cell.value is not None}
    required = ['variant_id', 'price', 'stock']
    if any(column_map.get(k) not in headers for k in required): raise ValueError('Column mapping does not match the actual seller template headers')
    start = int(column_map.get('first_data_row', header_row+1))
    for index, row in enumerate(rows, start):
        values = {'variant_id': int(row['variant_id']), 'price': wire_price(int(row['selling_price_toman']), column_map['price_currency']), 'stock': int(row['stock'])}
        for field, value in values.items(): ws.cell(index, headers[column_map[field]], value)
    workbook.save(output)

async def async_main(args):
    wp = WooSync()
    try:
        if args.command == 'map':
            with open(args.file, encoding='utf-8-sig', newline='') as f: rows = list(csv.DictReader(f))
            items = [{'wc_variation_id': int(r['wc_variation_id']), 'digikala_variant_id': int(r['digikala_variant_id'])} for r in rows]
            for start in range(0, len(items), 20): await wp.request('POST', '/sync/mapping', {'items': items[start:start+20]})
            print('Mappings saved:', len(items));return
        rows = [];cursor = 0
        for _ in range(250):
            page = await wp.request('GET', f'/sync/stock-export?after={cursor}');rows.extend(page['items'])
            if page.get('next_cursor') is None: break
            if page['next_cursor'] <= cursor: raise ValueError('Invalid seller export cursor')
            cursor = page['next_cursor']
        else: raise ValueError('Seller export exceeds bounded catalog limit')
        if args.command == 'sync':
            seller = Seller()
            try:
                for row in sorted(rows, key=lambda r: int(r['stock']) > 0): await seller.update(row)
            finally: await seller.close()
            print('Seller variants confirmed:', len(rows))
        elif args.command == 'csv':
            fields = ['variant_id', 'sku', 'size', 'selling_price_toman', 'stock', 'source_url', 'observed_at']
            with open(args.output, 'w', encoding='utf-8-sig', newline='') as f:
                writer = csv.DictWriter(f, fields, extrasaction='ignore');writer.writeheader();writer.writerows(rows)
            print('Canonical CSV written. This is not a universal Digikala category-import template.')
        elif args.command == 'excel':
            mapping = json.loads(Path(args.mapping).read_text(encoding='utf-8'))
            export_template(rows, args.template, args.output, args.sheet, mapping);print('Current seller template filled:', args.output)
        elif args.command == 'relay':
            # A normalized relay is intentionally separate from an undocumented native webhook.
            payload = json.loads(Path(args.file).read_text(encoding='utf-8'))
            if not payload.get('shipment_id') or not payload.get('customer') or not payload.get('items'): raise ValueError('Validated seller order relay required')
            await wp.request('POST', '/events/digikala', payload);print('Order relay accepted; no personal data logged.')
    finally: await wp.close()

def main():
    p = argparse.ArgumentParser();sub = p.add_subparsers(dest='command', required=True)
    sub.add_parser('sync');c=sub.add_parser('csv');c.add_argument('--output', required=True)
    e=sub.add_parser('excel');e.add_argument('--template', required=True);e.add_argument('--mapping', required=True);e.add_argument('--output', required=True);e.add_argument('--sheet')
    m=sub.add_parser('map');m.add_argument('--file', required=True)
    r=sub.add_parser('relay');r.add_argument('--file', required=True)
    asyncio.run(async_main(p.parse_args()))

if __name__ == '__main__': main()

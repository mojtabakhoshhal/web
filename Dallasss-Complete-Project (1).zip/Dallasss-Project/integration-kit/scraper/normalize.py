from __future__ import annotations

import hashlib
import re
from decimal import Decimal, ROUND_CEILING
from typing import Any
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

DIGITS = str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', '01234567890123456789')

def canonical_url(url: str) -> str:
    parts = urlsplit(url)
    if parts.scheme != 'https' or not parts.hostname or parts.username or parts.password:
        raise ValueError('Public HTTPS supplier URL required')
    query = [(k, v) for k, v in parse_qsl(parts.query, keep_blank_values=True)
             if not k.lower().startswith('utm_') and k.lower() not in {'fbclid', 'gclid'}]
    return urlunsplit(('https', parts.netloc.lower(), parts.path or '/', urlencode(sorted(query)), ''))

def source_hash(source: str, source_id: str, color: str) -> str:
    # Photo-derived color is descriptive metadata, never part of a stable product identity.
    return hashlib.md5(f'{source}|{source_id}'.encode(), usedforsecurity=False).hexdigest()

def metric_range(value: Any, unit: str = 'cm', flat_width: bool = False) -> dict[str, float]:
    text = str(value).translate(DIGITS).replace('٫', '.')
    numbers = re.findall(r'\d+(?:\.\d+)?', text)
    if len(numbers) == 1:
        n = metric(numbers[0], unit, flat_width);return {'min': n, 'max': n}
    if len(numbers) != 2 or not re.search(r'[-–تا]', text):
        raise ValueError('Ambiguous measurement range')
    lower, upper = [metric(n, unit, flat_width) for n in numbers]
    if lower > upper: raise ValueError('Reversed measurement range')
    return {'min': lower, 'max': upper}

def money(value: Any, currency: str) -> int:
    text = str(value).translate(DIGITS).strip().replace('٬', '').replace(',', '').replace(' ', '').replace('٫', '.')
    text = re.sub(r'(تومان|ریال|IRR|IRT|TMN)', '', text, flags=re.I)
    if not re.fullmatch(r'\d+(?:\.\d+)?', text):
        raise ValueError('Unambiguous numeric price required')
    result = Decimal(text)
    currency = currency.upper()
    if currency == 'IRR':
        result /= 10
    elif currency not in {'IRT', 'TMN'}:
        raise ValueError(f'Unknown currency {currency}; never guess Rial/Toman')
    if result != result.to_integral_value() or not 0 < result <= 1_000_000_000:
        raise ValueError('Integer Toman price outside supported bounds')
    return int(result)

def markup(source_price: int, bps: int = 3500, buffer: int = 0, rounding: int = 1) -> int:
    if source_price <= 0 or not 0 <= bps <= 10000 or buffer < 0 or rounding <= 0:
        raise ValueError('Invalid pricing policy')
    raw = (source_price * (10000 + bps) + 9999) // 10000 + buffer
    return ((raw + rounding - 1) // rounding) * rounding

def size_label(value: Any) -> str:
    label = re.sub(r'\s+', '', str(value).translate(DIGITS)).upper()
    return {'SMALL': 'S', 'MEDIUM': 'M', 'LARGE': 'L', 'XLARGE': 'XL', '2XL': 'XXL', 'XXXL': '3XL'}.get(label, label)[:50]

def metric(value: Any, unit: str = 'cm', flat_width: bool = False) -> float:
    text = str(value).translate(DIGITS).replace('٫', '.')
    nums = re.findall(r'\d+(?:\.\d+)?', text)
    if len(nums) != 1:
        raise ValueError('A size range must be reviewed; do not replace it with an invented measurement')
    number = Decimal(nums[0]) * (Decimal('2.54') if unit.lower() in {'in', 'inch', 'inches'} else 1)
    if unit.lower() not in {'cm', 'in', 'inch', 'inches'}:
        raise ValueError('Explicit cm/in unit required')
    if flat_width:
        number *= 2
    if not 20 <= number <= 180:
        raise ValueError('Measurement outside supported range')
    return round(float(number), 2)

def review_summary(reviews: list[dict]) -> dict:
    comments = []
    for review in reviews[:50]:
        text = str(review.get('reviewBody', '')).strip()
        if text and text not in comments:
            comments.append(text)
    fit_related = [t for t in comments if any(w in t for w in ['سایز', 'اندازه', 'قواره'])]
    positive = [t for t in fit_related if any(w in t for w in ['سایز مناسب', 'اندازه بود', 'سایزش دقیق', 'سایز دقیق'])
                and not any(w in t for w in ['نیست', 'نبود', 'کوچک', 'بزرگ بود', 'نامناسب'])]
    result = {'sample_count': len(comments), 'fit_mentions': len(fit_related), 'positive_fit_mentions': len(positive), 'method': 'explicit_keyword_rules', 'summary': None}
    if len(fit_related) >= 5:
        result['summary'] = f'{len(positive)} از {len(fit_related)} نظرِ مرتبط با سایز در نمونهٔ خوانده‌شده، به مناسب بودن سایز اشاره کرده‌اند.'
    elif comments:
        result['summary'] = f'{len(comments)} نظر در نمونهٔ خوانده‌شده؛ دادهٔ کافی برای نتیجه‌گیری دربارهٔ سایز وجود ندارد.'
    return result

def style_tags(title: str, category: str) -> tuple[list[str], list[str], str]:
    lower = title.lower()
    formal = any(w in lower for w in ['رسمی', 'کت تک', 'آکسفورد', 'formal', 'blazer'])
    street = any(w in lower for w in ['هودی', 'اورسایز', 'اسنیکر', 'دنیم', 'hoodie', 'street', 'oversized'])
    tags = [category, 'Formal' if formal else 'Streetwear' if street else 'Casual']
    occasions = ['office', 'date'] if formal else ['street', 'date'] if street else ['street', 'date', 'office']
    fit = 'Oversized' if any(w in lower for w in ['اورسایز', 'oversized']) else 'Slim' if any(w in lower for w in ['اسلیم', 'slim']) else 'Regular'
    return tags, occasions, fit

def category_of(title: str) -> str:
    t = title.lower()
    if any(w in t for w in ['شلوار', 'جین', 'دنیم', 'pants', 'jeans', 'trouser']): return 'Bottom'
    if any(w in t for w in ['کفش', 'کتانی', 'کتونی', 'اسنیکر', 'sneaker', 'shoe']): return 'Footwear'
    if any(w in t for w in ['کیف', 'کمربند', 'کلاه', 'ساعت', 'عینک', 'belt', 'bag', 'cap']): return 'Accessory'
    if any(w in t for w in ['پیراهن', 'تیشرت', 'تی شرت', 'هودی', 'کت ', 'کاپشن', 'پالتو', 'بلوز', 'shirt', 'jacket', 'hoodie', 'coat']): return 'Top'
    raise ValueError('Cannot safely infer a clothing category')

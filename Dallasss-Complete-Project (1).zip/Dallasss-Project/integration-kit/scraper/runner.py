from __future__ import annotations
import argparse
import asyncio
import json
import logging
import os
from pathlib import Path
from urllib.parse import urlsplit
from playwright.async_api import async_playwright
from .network import SafeClient, USER_AGENT, check_url
from .extract import structured, is_type, listing_urls, parse_product, dominant_color
from .sync import WooSync

LOG = logging.getLogger('dallasss')

async def browser_document(context, url: str, profile: dict, client: SafeClient):
    await check_url(url, client.hosts)
    if not await client.allowed(url): raise PermissionError('robots.txt disallows product/listing')
    page = await context.new_page();captured = [];tasks = []
    async def response_handler(response):
        if response.request.resource_type not in {'xhr', 'fetch'} or response.status != 200 or urlsplit(response.url).hostname not in client.hosts: return
        if 'json' not in response.headers.get('content-type', ''): return
        if int(response.headers.get('content-length', '0') or 0) > 2_000_000: return
        try:
            body = await response.body()
            if len(body) <= 2_000_000:
                from .extract import objects
                captured.extend(o for o in objects(json.loads(body)) if is_type(o, 'Product'))
        except Exception: pass
    def track(response): tasks.append(asyncio.create_task(response_handler(response)))
    page.on('response', track)
    async def route_handler(route):
        req = route.request
        if req.resource_type in {'image', 'media', 'font'}: await route.abort();return
        try:
            await check_url(req.url, client.hosts)
            if not await client.allowed(req.url): raise PermissionError('robots blocked resource')
            await route.continue_()
        except Exception: await route.abort()
    await page.route('**/*', route_handler)
    try:
        r = await page.goto(url, wait_until='domcontentloaded', timeout=30000)
        if not r or r.status >= 400: raise ValueError('Supplier returned an error; no stock assumptions will be made')
        await page.wait_for_timeout(1200)
        html = await page.content()
        if len(html) > 3_000_000: raise ValueError('HTML response exceeds processing bound')
        if tasks: await asyncio.gather(*tasks, return_exceptions=True)
        return html, captured
    finally: await page.close()

async def run(args):
    config = json.loads(Path(args.config).read_text(encoding='utf-8'))
    profiles = [p for p in config['sources'] if p.get('enabled') and p.get('permission_confirmed')]
    if not profiles: raise SystemExit('No permitted sources enabled. Run python -m scraper.configure first.')
    sync = WooSync() if args.push else None
    previous = await sync.index() if sync else []
    results = [];failures = 0
    async with async_playwright() as playwright:
        browser = await playwright.chromium.launch(headless=True)
        try:
            context = await browser.new_context(user_agent=USER_AGENT, locale='fa-IR', service_workers='block', accept_downloads=False)
            for profile in profiles:
                hosts = set(profile.get('page_hosts', []) + profile.get('api_hosts', []) + profile.get('image_hosts', []))
                client = SafeClient(hosts)
                try:
                    urls = list(profile.get('product_urls', []))
                    if args.mode == 'full':
                        for listing in profile.get('listing_urls', [])[:4]:
                            if profile.get('ranking') not in {'bestseller', 'mostviewed'}: raise ValueError('An explicitly verified ranking is required for listing discovery')
                            html, _ = await browser_document(context, listing, profile, client)
                            urls.extend(listing_urls(html, listing, set(profile['page_hosts'])))
                    urls.extend(p['payload']['source_url'] for p in previous if p['payload']['source'] == profile['source'])
                    urls = list(dict.fromkeys(urls))[:config.get('max_products_per_source', 40)]
                    async def observe(url):
                        nonlocal failures
                        async with semaphore:
                            try:
                                if args.mode == 'delta':
                                    body, _ = await client.get(url, limit=3_000_000)
                                    html, xhr = body.decode('utf-8', errors='replace'), []
                                    if not any(is_type(o, 'Product') for o in structured(html)):
                                        html, xhr = await browser_document(context, url, profile, client)
                                else:
                                    html, xhr = await browser_document(context, url, profile, client)
                                docs = [o for o in structured(html) if is_type(o, 'Product')] or xhr
                                if not docs: raise ValueError('No supported JSON-LD Product; source-specific adapter needs captured evidence')
                                from urllib.parse import urljoin
                                image = docs[0].get('image', [])
                                image = image[0] if isinstance(image, list) and image else image
                                image = image.get('url') if isinstance(image, dict) else image
                                # Keep identity stable across photo/color estimation changes.
                                existing = next((p['payload'] for p in previous if p['payload']['source_url'] == url), None)
                                color = existing['color'] if existing else await dominant_color(urljoin(url, str(image)), client)
                                result = parse_product(docs[0], html, url, profile, color)
                                for image_url in result['images']: await check_url(image_url, set(profile.get('image_hosts', [])))
                                results.append(result)
                            except Exception as error:
                                failures += 1
                                LOG.warning('Observation rejected for source=%s error=%s', profile['source'], type(error).__name__)
                            await asyncio.sleep(config.get('request_delay_seconds', 2))
                    semaphore = asyncio.Semaphore(2)
                    await asyncio.gather(*(observe(u) for u in urls))
                finally: await client.close()
            await context.close()
        finally: await browser.close()
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    Path(args.output).write_text(json.dumps({'schema_version': 1, 'products': results, 'rejected': failures}, ensure_ascii=False, indent=2), encoding='utf-8')
    if sync:
        try: await sync.push(results)
        finally: await sync.close()
    LOG.info('Valid observations=%d rejected=%d', len(results), failures)
    if not results: raise SystemExit('No valid observations. Existing quotes will expire; inventory is not invented.')

def main():
    p = argparse.ArgumentParser();p.add_argument('--mode', choices=['full', 'delta'], required=True)
    p.add_argument('--config', default='config/sources.local.json');p.add_argument('--output', default='run-output/catalog.json');p.add_argument('--push', action='store_true')
    logging.basicConfig(level=logging.INFO, format='%(levelname)s %(message)s')
    asyncio.run(run(p.parse_args()))

if __name__ == '__main__': main()

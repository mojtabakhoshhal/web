from __future__ import annotations
import asyncio
import os
from urllib.parse import urlsplit
import httpx
from .normalize import markup

class WooSync:
    def __init__(self):
        self.base = os.getenv('WP_BASE_URL', 'https://dallasss.ir').rstrip('/')
        p = urlsplit(self.base)
        local = p.hostname in {'localhost', '127.0.0.1'} and os.getenv('DALLASSS_ALLOW_LOCAL_HTTP') == '1'
        if (p.scheme != 'https' and not local) or p.username or p.password or p.query or p.fragment:
            raise ValueError('WP_BASE_URL must be a credential-free HTTPS origin')
        required = ['WC_CONSUMER_KEY', 'WC_CONSUMER_SECRET', 'WP_USER', 'WP_APP_PASSWORD']
        if any(not os.getenv(k) for k in required): raise ValueError('Configure WooCommerce and WordPress application credentials in the environment')
        self.wc_auth = httpx.BasicAuth(os.environ['WC_CONSUMER_KEY'], os.environ['WC_CONSUMER_SECRET'])
        self.wp_auth = httpx.BasicAuth(os.environ['WP_USER'], os.environ['WP_APP_PASSWORD'])
        self.http = httpx.AsyncClient(timeout=httpx.Timeout(70, connect=15), follow_redirects=False, limits=httpx.Limits(max_connections=2))

    async def close(self): await self.http.aclose()

    async def request(self, method: str, path: str, payload=None, woo=False):
        prefix = '/wp-json/wc/v3' if woo else '/wp-json/dallasss/v1'
        for attempt in range(4):
            try:
                r = await self.http.request(method, self.base + prefix + path, json=payload,
                                            auth=self.wc_auth if woo else self.wp_auth)
                if 300 <= r.status_code < 400: raise ValueError('REST redirect rejected; set the canonical HTTPS origin')
                if r.status_code == 429 or r.status_code >= 500:
                    # Only reads are retried automatically. A POST timeout may already have committed.
                    if method != 'GET' or attempt == 3: r.raise_for_status()
                    retry = r.headers.get('retry-after', '')
                    await asyncio.sleep(min(30, int(retry)) if retry.isdigit() else 2 ** (attempt + 1));continue
                r.raise_for_status()
                return r.json()
            except (httpx.TimeoutException, httpx.NetworkError):
                if method != 'GET' or attempt == 3: raise
                await asyncio.sleep(2 ** (attempt + 1))
        raise RuntimeError('Read retry budget exhausted')

    async def index(self):
        result = [];cursor = 0
        for _ in range(100):
            response = await self.request('GET', f'/sync/catalog?after={cursor}')
            result.extend(response['items'])
            if response['next_cursor'] is None: return result
            if response['next_cursor'] <= cursor: raise ValueError('Server returned a non-increasing cursor')
            cursor = response['next_cursor']
        raise ValueError('Catalog exceeds bounded 10,000-product index; paginate the integration deliberately')

    async def products_by_sku(self, skus: list[str]):
        if not skus: return {}
        r = await self.request('GET', '/products?per_page=20&status=any&sku=' + ','.join(skus), woo=True)
        return {p['sku']: p for p in r}

    async def push(self, products: list[dict]):
        policy = await self.request('GET', '/sync/policy')
        for offset in range(0, len(products), 20):
            chunk = products[offset:offset+20]
            existing = await self.products_by_sku(['DS-' + p['source_hash'] for p in chunk])
            creates, updates = [], []
            for p in chunk:
                sku = 'DS-' + p['source_hash']
                item = {'name': p['title'], 'type': 'variable', 'status': 'publish', 'sku': sku,
                        'attributes': [{'name': 'Size', 'visible': True, 'variation': True, 'options': list(dict.fromkeys(v['size'] for v in p['variants']))}],
                        'meta_data': [{'key': '_dallasss_source_hash', 'value': p['source_hash']}, {'key': '_dallasss_payload', 'value': p}]}
                if sku in existing: item['id'] = existing[sku]['id'];updates.append(item)
                else: creates.append(item)
            try:
                response = await self.request('POST', '/products/batch', {'create': creates, 'update': updates}, woo=True)
                errors = [p['error']['code'] for kind in ['create', 'update'] for p in response.get(kind, []) if p.get('error')]
                if errors: raise RuntimeError('WooCommerce rejected batch items: ' + ','.join(errors))
            except (httpx.TimeoutException, httpx.NetworkError):
                # Resolve ambiguous creation using immutable SKUs, then stop. Rerunning performs updates, not blind duplicate creates.
                resolved = await self.products_by_sku(['DS-' + p['source_hash'] for p in chunk])
                raise RuntimeError(f'Unconfirmed batch. {len(resolved)}/{len(chunk)} immutable SKUs exist; rerun to reconcile safely.') from None
            await asyncio.sleep(2)
            saved = await self.products_by_sku(['DS-' + p['source_hash'] for p in chunk])
            for p in chunk:
                parent = saved.get('DS-' + p['source_hash'])
                if not parent: raise RuntimeError('Parent was not confirmed after batch import')
                await self.variations(parent['id'], p, policy)
                await self.request('POST', '/sync/finalize', {'product_id': parent['id'], 'source_hash': p['source_hash'], 'observed_at': p['observed_at']})
                await asyncio.sleep(2)

    async def variations(self, parent_id: int, product: dict, policy: dict):
        existing = await self.request('GET', f'/products/{parent_id}/variations?per_page=100', woo=True)
        by_key = {next((m['value'] for m in v.get('meta_data', []) if m['key'] == '_dallasss_variant_key'), ''): v for v in existing}
        all_items = []
        for v in product['variants']:
            key = v['key'];price = markup(v['source_price_toman'], policy['markup_bps'], policy['shipping_buffer'], policy['rounding'])
            item = {'sku': 'DSV-' + product['source_hash'] + '-' + __import__('hashlib').sha256(key.encode()).hexdigest()[:12],
                    'regular_price': str(price * (10 if policy['currency'] == 'IRR' else 1)), 'manage_stock': True,
                    'stock_quantity': 0, 'backorders': 'no', 'attributes': [{'name': 'Size', 'option': v['size']}],
                    'meta_data': [{'key': '_dallasss_variant_key', 'value': key}]}
            if key in by_key: item['id'] = by_key[key]['id']
            all_items.append(item)
        for offset in range(0, len(all_items), 20):
            chunk = all_items[offset:offset+20]
            data = {'create': [i for i in chunk if 'id' not in i], 'update': [i for i in chunk if 'id' in i]}
            response = await self.request('POST', f'/products/{parent_id}/variations/batch', data, woo=True)
            errors = [i['error']['code'] for k in ['create', 'update'] for i in response.get(k, []) if i.get('error')]
            if errors: raise RuntimeError('Variant batch rejected: ' + ','.join(errors))
            await asyncio.sleep(2)

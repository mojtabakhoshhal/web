from __future__ import annotations
import asyncio
import ipaddress
import socket
from urllib.parse import urlsplit
from urllib.robotparser import RobotFileParser
import httpx

USER_AGENT = 'DallasssCatalog/1.0 (+https://dallasss.ir; supplier-permitted catalog sync)'

async def check_url(url: str, hosts: set[str]) -> None:
    p = urlsplit(url)
    if p.scheme != 'https' or p.hostname not in hosts or p.username or p.password or p.port not in {None, 443}:
        raise ValueError('URL outside explicit HTTPS host allowlist')
    addresses = await asyncio.to_thread(socket.getaddrinfo, p.hostname, 443, type=socket.SOCK_STREAM)
    if not addresses or any(not ipaddress.ip_address(a[4][0]).is_global for a in addresses):
        raise ValueError('Non-public network address rejected')

class SafeClient:
    def __init__(self, hosts: set[str], concurrency: int = 2):
        self.hosts = hosts
        self.semaphore = asyncio.Semaphore(concurrency)
        self.http = httpx.AsyncClient(timeout=httpx.Timeout(25, connect=10), follow_redirects=False,
                                     limits=httpx.Limits(max_connections=4), headers={'User-Agent': USER_AGENT})
        self.robots: dict[str, RobotFileParser] = {}

    async def close(self): await self.http.aclose()

    async def get(self, url: str, limit: int = 2_000_000, robots: bool = True) -> tuple[bytes, str]:
        await check_url(url, self.hosts)
        if robots and not await self.allowed(url): raise PermissionError('robots.txt disallows this URL')
        async with self.semaphore:
            for attempt in range(3):
                response = None
                async with self.http.stream('GET', url) as response:
                    if response.status_code == 429 or response.status_code >= 500:
                        if attempt == 2: response.raise_for_status()
                        retry = response.headers.get('retry-after', '')
                        delay = min(30, int(retry)) if retry.isdigit() else 2 ** (attempt + 1)
                    else:
                        response.raise_for_status()
                        if 300 <= response.status_code < 400: raise ValueError('Redirect requires explicit review of the destination URL')
                        body = bytearray()
                        async for chunk in response.aiter_bytes():
                            body.extend(chunk)
                            if len(body) > limit: raise ValueError('Response exceeds bounded download size')
                        return bytes(body), response.headers.get('content-type', '')
                await asyncio.sleep(delay)
        raise RuntimeError('Network request exhausted retries')

    async def allowed(self, url: str) -> bool:
        p = urlsplit(url);origin = f'https://{p.hostname}'
        if origin not in self.robots:
            parser = RobotFileParser();parser.set_url(origin + '/robots.txt')
            try:
                body, _ = await self.get(parser.url, limit=100_000, robots=False)
                parser.parse(body.decode('utf-8', errors='replace').splitlines())
            except httpx.HTTPStatusError as e:
                parser.parse(['User-agent: *', 'Disallow: /'] if e.response.status_code != 404 else ['User-agent: *', 'Allow: /'])
            except Exception:
                parser.parse(['User-agent: *', 'Disallow: /'])
            self.robots[origin] = parser
        return self.robots[origin].can_fetch(USER_AGENT, url)

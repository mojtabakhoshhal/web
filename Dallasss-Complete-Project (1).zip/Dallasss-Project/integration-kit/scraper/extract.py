from __future__ import annotations
import io
import json
import re
from datetime import datetime, timezone
from urllib.parse import urljoin
from bs4 import BeautifulSoup
from PIL import Image, ImageOps
from .normalize import DIGITS, canonical_url, category_of, metric, metric_range, money, review_summary, size_label, source_hash, style_tags

def objects(value):
    if isinstance(value, dict):
        yield value
        for child in value.values(): yield from objects(child)
    elif isinstance(value, list):
        for child in value: yield from objects(child)

def is_type(obj, name):
    value = obj.get('@type', [])
    return name in (value if isinstance(value, list) else [value])

def structured(html: str) -> list[dict]:
    soup = BeautifulSoup(html, 'html.parser');result = []
    for script in soup.find_all('script', type='application/ld+json'):
        try: result.extend(objects(json.loads(script.string or script.get_text())))
        except (ValueError, TypeError): continue
    return result

def listing_urls(html: str, origin: str, hosts: set[str]) -> list[str]:
    from urllib.parse import urlsplit
    links = []
    for obj in structured(html):
        if is_type(obj, 'Product') and obj.get('url'): links.append(urljoin(origin, obj['url']))
        if is_type(obj, 'ListItem'):
            item = obj.get('item', {})
            value = item if isinstance(item, str) else item.get('url', item.get('@id', ''))
            if value: links.append(urljoin(origin, value))
    return list(dict.fromkeys(canonical_url(u) for u in links if urlsplit(u).hostname in hosts))

def size_table(html: str, declared_unit: str | None) -> dict[str, dict[str, float]]:
    if declared_unit not in {'cm', 'in'}: return {}
    soup = BeautifulSoup(html, 'html.parser');result = {}
    for table in soup.find_all('table'):
        rows = table.find_all('tr')
        if len(rows) < 2: continue
        headers = [cell.get_text(' ', strip=True).lower() for cell in rows[0].find_all(['th', 'td'])]
        label_index = next((i for i, h in enumerate(headers) if h in {'سایز', 'اندازه', 'size'}), None)
        if label_index is None: continue
        for row in rows[1:]:
            cells = [c.get_text(' ', strip=True) for c in row.find_all(['td', 'th'])]
            if len(cells) != len(headers): continue
            item = {}
            for h, value in zip(headers, cells):
                field = 'chest' if any(w in h for w in ['سینه', 'chest']) else 'waist' if any(w in h for w in ['کمر', 'waist']) else 'shoulder' if any(w in h for w in ['شانه', 'سرشانه', 'shoulder']) else None
                if not field: continue
                # Circumferences are doubled only when the source explicitly labels a flat width.
                flat = field in {'chest', 'waist'} and any(w in h for w in ['عرض', 'half', 'flat'])
                if field in {'chest', 'waist'} and not flat and not any(w in h for w in ['دور', 'circumference']): continue
                try:
                    measured = metric_range(value, declared_unit, flat)
                    if measured['min'] == measured['max']: item[field] = measured['min']
                    else: item.setdefault('_ranges', {})[field] = measured
                except ValueError: continue
            if item: result[size_label(cells[label_index])] = item
    return result

def extract_bnpl(html: str, profile: dict, source_url: str) -> dict | None:
    rule = profile.get('bnpl')
    if not rule or not rule.get('terms_confirmed') or not rule.get('eligible_selector') or not rule.get('first_payment_selector'): return None
    soup = BeautifulSoup(html, 'html.parser')
    eligible = soup.select_one(rule['eligible_selector']);payment = soup.select_one(rule['first_payment_selector'])
    if not eligible or not payment: return None
    text = eligible.get_text(' ', strip=True).translate(DIGITS)
    if 'اسنپ' not in text or not re.search(r'4\s*قسط', text): return None
    first = money(payment.get_text(' ', strip=True), rule.get('currency', profile['currency']))
    affiliate = rule.get('affiliate_urls', {}).get(source_url)
    return {'provider': 'snapppay', 'count': 4, 'first_payment_toman': first, 'verified': True,
            'affiliate_approved': bool(rule.get('affiliate_approved') and affiliate), 'affiliate_url': affiliate,
            'evidence_url': source_url}

async def dominant_color(url: str, client) -> str:
    data, media_type = await client.get(url, limit=2_000_000)
    if not media_type.startswith('image/'): raise ValueError('Image content type required')
    Image.MAX_IMAGE_PIXELS = 24_000_000
    with Image.open(io.BytesIO(data)) as image:
        image.thumbnail((72, 72))
        image = ImageOps.exif_transpose(image).convert('RGB')
        # Center crop reduces white catalog backgrounds; this is a color estimate, not a garment segmentation model.
        w, h = image.size;image = image.crop((w//4, h//4, max(w//4+1, 3*w//4), max(h//4+1, 3*h//4)))
        palette = image.quantize(colors=5, method=Image.Quantize.MEDIANCUT).convert('RGB')
        counts = sorted(palette.getcolors(72*72) or [], reverse=True)
        candidates = [c for _, c in counts if min(c) < 225 and max(c) > 18]
        color = candidates[0] if candidates else counts[0][1]
        return '#' + ''.join(f'{c:02x}' for c in color)

def parse_product(document: dict, html: str, url: str, profile: dict, color: str) -> dict:
    title = str(document.get('name', '')).strip()
    if not title: raise ValueError('JSON-LD product title missing')
    category = category_of(title);tags, occasions, fit = style_tags(title, category)
    all_offers = document.get('offers', [])
    if isinstance(all_offers, dict): all_offers = [all_offers]
    source_id = str(document.get('productID') or document.get('sku') or canonical_url(url))
    if len(source_id.encode()) > 191: source_id = __import__('hashlib').sha256(source_id.encode()).hexdigest()
    variants = [];chart = size_table(html, profile.get('size_table_unit'))
    children = document.get('hasVariant', [])
    if isinstance(children, dict): children = [children]
    variant_docs = children or [document]
    variant_colors = {str(v.get('color')).strip() for v in variant_docs if v.get('color')}
    if len(variant_colors) > 1: raise ValueError('Multiple supplier colors must be split using verified color-specific source identities')
    for index, variant in enumerate(variant_docs):
        offers = variant.get('offers', all_offers)
        if isinstance(offers, dict): offers = [offers]
        if not offers: continue
        # Multi-vendor AggregateOffer lowPrice is not a purchasable supplier quote.
        offer = next((o for o in offers if 'price' in o and not is_type(o, 'AggregateOffer')), None)
        if not offer: continue
        currency = offer.get('priceCurrency') or profile.get('currency')
        amount = money(offer['price'], currency or '')
        availability = str(offer.get('availability', ''))
        level = offer.get('inventoryLevel', variant.get('inventoryLevel'))
        if isinstance(level, dict): level = level.get('value')
        quantity = int(level) if isinstance(level, (int, float)) and level == int(level) and 0 <= level <= 10000 else None
        if availability.endswith(('OutOfStock', 'Discontinued', 'SoldOut')): quantity = 0
        size = size_label(variant.get('size') or offer.get('size') or '')
        if not size: size = 'ONE' if category == 'Accessory' else 'UNSPECIFIED'
        # A sized garment without an actual source size cannot be sold directly.
        if size == 'UNSPECIFIED': quantity = None
        key = str(variant.get('sku') or offer.get('sku') or size)
        if not re.fullmatch(r'[A-Za-z0-9._-]{1,70}', key): key = __import__('hashlib').sha256(key.encode()).hexdigest()[:24]
        dimensions = chart.get(size, {}).copy();ranges = dimensions.pop('_ranges', {})
        variants.append({'key': key, 'size': size, 'quantity': quantity, 'source_price_toman': amount,
                         'measurements_cm': dimensions, 'measurement_ranges_cm': ranges, 'availability_reported': availability})
    if not variants: raise ValueError('No concrete offer with an explicit price and currency')
    if len({v['key'] for v in variants}) != len(variants): raise ValueError('Ambiguous variant identifiers')
    raw_images = document.get('image', [])
    if not isinstance(raw_images, list): raw_images = [raw_images]
    images = [urljoin(url, i if isinstance(i, str) else i.get('url', '')) for i in raw_images if i][:8]
    reviews = document.get('review', [])
    if isinstance(reviews, dict): reviews = [reviews]
    summary = review_summary(reviews)
    explicit_color = str(document.get('color', ''))
    if re.fullmatch(r'#[0-9a-fA-F]{6}', explicit_color): color = explicit_color.lower()
    return {'schema_version': 1, 'source': profile['source'], 'source_id': source_id,
            'source_hash': source_hash(profile['source'], source_id, color), 'source_url': canonical_url(url),
            'title': title, 'source_price_toman': min(v['source_price_toman'] for v in variants),
            'images': images, 'color': color, 'color_method': 'source_hex' if explicit_color == color else 'center_crop_quantization',
            'category': category, 'tags': tags, 'occasions': occasions, 'fit': fit, 'variants': variants[:40],
            'observed_at': datetime.now(timezone.utc).isoformat(),
            'review_summary': summary['summary'], 'review_evidence': summary,
            'ranking': profile.get('ranking'), 'bnpl': extract_bnpl(html, profile, canonical_url(url))}

-- Reference DDL for the default wp_ prefix. Plugin activation uses the actual WordPress prefix.

CREATE TABLE wp_dallasss_offers (
        id bigint unsigned NOT NULL AUTO_INCREMENT,
        source_hash char(32) NOT NULL,
        source varchar(24) NOT NULL,
        source_id varchar(191) NOT NULL,
        product_id bigint unsigned NOT NULL,
        source_price_toman bigint unsigned NOT NULL DEFAULT 0,
        selling_price_toman bigint unsigned NOT NULL DEFAULT 0,
        observed_at datetime NOT NULL,
        payload longtext NOT NULL,
        created_at datetime NOT NULL,
        updated_at datetime NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY source_hash (source_hash),
        UNIQUE KEY product_id (product_id),
        KEY freshness (observed_at),
        KEY source_cursor (source,id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;;

CREATE TABLE wp_dallasss_price_history (
        id bigint unsigned NOT NULL AUTO_INCREMENT,
        source_hash char(32) NOT NULL,
        source_price_toman bigint unsigned NOT NULL,
        selling_price_toman bigint unsigned NOT NULL,
        observed_at datetime NOT NULL,
        observation_key char(64) NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY observation_key (observation_key),
        KEY history_lookup (source_hash,observed_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;;

CREATE TABLE wp_dallasss_reservations (
        id bigint unsigned NOT NULL AUTO_INCREMENT,
        order_item_id bigint unsigned NOT NULL,
        order_id bigint unsigned NOT NULL,
        variation_id bigint unsigned NOT NULL,
        quantity int unsigned NOT NULL,
        state varchar(20) NOT NULL DEFAULT 'held',
        created_at datetime NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY order_item_id (order_item_id),
        KEY variation_state (variation_id,state),
        KEY order_id (order_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;;

CREATE TABLE wp_dallasss_outbox (
        id bigint unsigned NOT NULL AUTO_INCREMENT,
        event_key varchar(191) NOT NULL,
        order_id bigint unsigned NOT NULL DEFAULT 0,
        payload longtext NOT NULL,
        state varchar(20) NOT NULL DEFAULT 'pending',
        attempts int unsigned NOT NULL DEFAULT 0,
        created_at datetime NOT NULL,
        updated_at datetime NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY event_key (event_key),
        KEY queue (state,updated_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;;


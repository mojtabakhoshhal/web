from pathlib import Path
import html
import re
import shutil
import zipfile

ROOT=Path(__file__).resolve().parents[1]
DIST=ROOT/'dist';KIT=ROOT/'integration-kit';DOWNLOADS=DIST/'downloads'
DOWNLOADS.mkdir(exist_ok=True)

def inline(text):
    text=html.escape(text)
    text=re.sub(r'`([^`]+)`',r'<code dir="ltr">\1</code>',text)
    text=re.sub(r'https://[^\s<>]+',lambda m:'<a href="'+m.group(0)+'" target="_blank" rel="noopener noreferrer">'+m.group(0)+'</a>',text)
    return text

def markdown(text):
    output=[];paragraph=[];code=[];in_code=False;in_list=False;heading=0
    def flush():
        if paragraph:output.append('<p>'+inline(' '.join(paragraph))+'</p>');paragraph.clear()
    for line in text.splitlines():
        if line.startswith('```'):
            flush()
            if in_code:output.append('<pre dir="ltr"><code>'+html.escape('\n'.join(code))+'</code></pre>');code=[]
            in_code=not in_code;continue
        if in_code:code.append(line);continue
        if not line.strip():flush();continue
        if line.startswith('#'):
            flush()
            if in_list:output.append('</ul>');in_list=False
            count=len(line)-len(line.lstrip('#'));heading+=1
            output.append(f'<h{count} id="section-{heading}">'+inline(line[count:].strip())+f'</h{count}>');continue
        if line.startswith('- '):
            flush()
            if not in_list:output.append('<ul>');in_list=True
            output.append('<li>'+inline(line[2:])+'</li>');continue
        if in_list:output.append('</ul>');in_list=False
        paragraph.append(line)
    flush()
    if in_list:output.append('</ul>')
    return '\n'.join(output)

# Reuse one verified frontend source in the static preview and the WordPress package.
front=KIT/'wordpress/dallasss-core/storefront';assets=front/'assets';assets.mkdir(parents=True,exist_ok=True)
for old in assets.iterdir():
    if old.is_file():old.unlink()
for source in (DIST/'assets').iterdir():
    if source.suffix in {'.mjs','.css','.woff2','.svg'} or source.name in {'hero.jpg','editorial.jpg'}:
        shutil.copy2(source,assets/source.name)
body=(DIST/'index.html').read_text().split('<body>',1)[1].rsplit('</body>',1)[0]
body=re.sub(r'<a href="\./implementation.html">[^<]*</a>','',body)
(front/'storefront.html').write_text(body,encoding='utf-8')
schema=(KIT/'wordpress/dallasss-core/includes/schema.php').read_text()
statements=re.findall(r'dbDelta\("(CREATE TABLE .*?)"\);',schema,re.S)
sql='-- Reference DDL for the default wp_ prefix. Plugin activation uses the actual WordPress prefix.\n\n'
for statement in statements:
    sql+=statement.replace('{$prefix}','wp_dallasss_').replace('$charset','ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci')+';\n\n'
(KIT/'database.sql').write_text(sql)

for folder,name in [('dallasss-core','dallasss-core.zip'),('dallasss-shell','dallasss-shell.zip')]:
    directory=KIT/'wordpress'/folder
    with zipfile.ZipFile(DOWNLOADS/name,'w',zipfile.ZIP_DEFLATED) as z:
        for file in sorted(directory.rglob('*')):
            if file.is_file():z.write(file,file.relative_to(directory.parent))
with zipfile.ZipFile(DOWNLOADS/'dallasss-implementation.zip','w',zipfile.ZIP_DEFLATED) as z:
    for file in sorted(KIT.rglob('*')):
        if not file.is_file() or any(p in {'.venv','__pycache__','run-output'} for p in file.relative_to(KIT).parts) or file.name in {'.env','sources.local.json','wp-config.php'} or file.suffix=='.pyc':continue
        z.write(file,file.relative_to(KIT))
for name in ['README.fa.md','ARCHITECTURE.md','database.sql']:shutil.copy2(KIT/name,DOWNLOADS/name)

guide=markdown((KIT/'README.fa.md').read_text())
page='''<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>راهنمای راه‌اندازی دالاس — کد و معماری</title><meta name="robots" content="noindex"><link rel="icon" href="./assets/favicon.svg"><link rel="stylesheet" href="./assets/style.css"><style>
body{background:#0b0f19}.guide-header{padding:30px 5%;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid #ffffff20}.guide-layout{display:grid;grid-template-columns:260px minmax(0,850px);gap:65px;padding:50px 5%;align-items:start;justify-content:center}.guide-sidebar{position:sticky;top:25px;border:1px solid #ffffff20;padding:24px;background:#121a27}.guide-sidebar>span{font:9px Arial;color:#c9b47d;letter-spacing:2px}.guide-sidebar h2{font-size:23px;margin:13px 0}.guide-sidebar a{display:block;color:#c9b47d;font-size:11px;margin-top:15px}.guide-sidebar p{font-size:10px;color:#8994a4;margin-top:15px}.guide-sidebar .button{margin:20px 0 0;color:#0b0f19}.guide-content{min-width:0}.guide-content h1{font-size:38px;line-height:1.6;margin-bottom:20px}.guide-content h2{font-size:26px;border-top:1px solid #ffffff1a;padding-top:30px;margin:50px 0 20px;letter-spacing:-.6px}.guide-content h3{font-size:19px;color:#d9cba7;margin:28px 0 16px}.guide-content p,.guide-content li{font-size:13px;line-height:2.5;color:#b1b8c3;margin:15px 0}.guide-content a{color:#c9b47d;overflow-wrap:anywhere}.guide-content code{color:#e0d3b3;font-size:11px;background:#ffffff07;padding:2px 4px}.guide-content pre{background:#121d2b;border:1px solid #ffffff16;padding:20px;overflow-x:auto;white-space:pre;line-height:2;text-align:left;margin:20px 0}.guide-content pre code{background:none;color:#c8d3e0}.guide-note{border-right:3px solid #c9b47d;background:#c9b47d0a;padding:20px 25px;margin-bottom:30px;color:#c4b997;font-size:12px;line-height:2.3}.guide-content ul{padding-right:20px}@media(max-width:950px){.guide-layout{grid-template-columns:1fr;gap:35px}.guide-sidebar{position:static;display:block}.guide-content h1{font-size:30px}.guide-header .wordmark{font-size:25px}}@media(max-width:600px){.guide-header{padding:25px 6%}.guide-layout{padding:30px 6%}.guide-content p,.guide-content li{font-size:12px}.guide-content h2{font-size:23px}.guide-header>a:last-child{font-size:11px}}
</style></head><body><header class="guide-header"><a class="wordmark" href="./">DALLASSS<span>IMPLEMENTATION / 01</span></a><a href="./">بازگشت به ویترین ↗</a></header><main class="guide-layout"><aside class="guide-sidebar"><span>THE BUILD BOOK</span><h2>از طرح تا فروشگاه</h2><p>راهنمای شش‌مرحله‌ای، معماری، تنظیمات هاست و کدهای قابل نصب.</p><a class="button gold" download href="./downloads/dallasss-implementation.zip">دانلود بستهٔ کامل ↓</a><a download href="./downloads/dallasss-core.zip">افزونهٔ وردپرس ↓</a><a download href="./downloads/dallasss-shell.zip">پوستهٔ سبک وردپرس ↓</a><a download href="./downloads/README.fa.md">راهنمای فارسی کامل ↓</a><a download href="./downloads/ARCHITECTURE.md">معماری و قراردادهای داده ↓</a><a download href="./downloads/database.sql">طرح SQL دیتابیس ↓</a><p>قیمت پایه: منبع × ۱٫۳۵<br>ارسال: جداگانه<br>پیش‌نمایش: محصولات نمونه<br>فروش واقعی: نیازمند اتصال پنل‌ها</p></aside><article class="guide-content"><div class="guide-note">این تحویل شامل ویترین فعال و کدهای نصب روی هاست شماست. فروش واقعی، حساب‌های فروشنده، پرداخت، تأمین‌کنندگان و پرو تصویری خارجی هنوز متصل و آزموده نشده‌اند. مراحل دقیق هر اتصال در همین صفحه آمده است.</div>'''+guide+'''</article></main></body></html>'''
(DIST/'implementation.html').write_text(page,encoding='utf-8')
for path in DOWNLOADS.iterdir():print(path.name,path.stat().st_size)

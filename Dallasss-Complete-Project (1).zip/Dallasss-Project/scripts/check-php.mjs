import fs from 'node:fs';
import Engine from 'php-parser';
const parser=new Engine({parser:{suppressErrors:false,phpVersion:'8.2'}});
let count=0;
function walk(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){const path=dir+'/'+e.name;if(e.isDirectory())walk(path);else if(path.endsWith('.php')){parser.parseCode(fs.readFileSync(path,'utf8'),path);count++;}}}
walk('integration-kit/wordpress');walk('integration-kit/hosting');console.log(`${count} PHP files parsed successfully as PHP 8.2.`);

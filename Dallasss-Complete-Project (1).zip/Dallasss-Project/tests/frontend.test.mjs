import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {parseHTML} from 'linkedom';
import {DEMO_PRODUCTS} from '../dist/assets/catalog.mjs';
import {markup,matchOutfit,recommendSize,referenceBody,validateCart,escapeHTML} from '../dist/assets/core.mjs';

test('markup applies exactly 35% and rounds only fractional Tomans upward',()=>{assert.equal(markup(1000000),1350000);assert.equal(markup(1010000),1363500);assert.equal(markup(1001),1352);});
test('every illustrative product uses the same 35% supplier markup',()=>{for(const p of DEMO_PRODUCTS)assert.equal(p.price,Math.ceil(p.sourcePrice*135/100));});
test('outfits contain all three garment classes and three distinct suppliers within budget',()=>{for(const anchor of DEMO_PRODUCTS){const m=matchOutfit(DEMO_PRODUCTS,anchor,8000000);assert.ok(m);assert.equal(new Set(m.items.map(p=>p.source)).size,3);assert.deepEqual(m.items.map(p=>p.category),['Top','Bottom','Footwear']);assert.ok(m.total<=8000000);assert.ok(m.items.every(p=>p.stock>0));}});
test('a low budget produces an explicit no-match result',()=>assert.equal(matchOutfit(DEMO_PRODUCTS,DEMO_PRODUCTS[0],1000000),null));
test('size recommendation reports the best unavailable size instead of pretending a poor fit is correct',()=>{const chart=[{label:'M',chest:104,waist:98,shoulder:47,stock:3},{label:'L',chest:112,waist:106,shoulder:49,stock:0}];const fit=recommendSize(chart,{chest:104,waist:98,shoulder:47});assert.equal(fit.label,'L');assert.equal(fit.available,false);});
test('no measurements do not produce an invented size',()=>assert.equal(recommendSize(DEMO_PRODUCTS[0].sizes,{}),null));
test('a vendor label without physical measurements cannot produce a size recommendation',()=>assert.equal(recommendSize([{label:'L',stock:5}],{chest:102}),null));
test('reference fit is explicitly low-confidence when only one body dimension is known',()=>{const r=recommendSize(DEMO_PRODUCTS[0].sizes,{chest:102});assert.equal(r.confidence,'low');assert.equal(referenceBody('L').chest,102);});
test('cart rejects missing garments, unavailable sizes and quantities above exact size stock',()=>{const lines=[{id:1,size:'L',quantity:2},{id:1,size:'L',quantity:3},{id:5,size:'43',quantity:1},{id:999,size:'M',quantity:1}];assert.deepEqual(validateCart(lines,DEMO_PRODUCTS),[lines[0]]);});
test('supplier content is escaped before it enters generated HTML',()=>{assert.equal(escapeHTML('<img src=x onerror="bad">'), '&lt;img src=x onerror=&quot;bad&quot;&gt;');});
test('page structure has unique element IDs, meaningful image alternatives and named controls',()=>{const {document}=parseHTML(fs.readFileSync(new URL('../dist/index.html',import.meta.url),'utf8'));const ids=[...document.querySelectorAll('[id]')].map(e=>e.id);assert.equal(new Set(ids).size,ids.length);for(const image of document.querySelectorAll('img'))assert.ok(image.getAttribute('alt'));for(const button of document.querySelectorAll('button'))assert.ok(button.textContent.trim()||button.getAttribute('aria-label'));});
test('storefront renders, filters favorites and supports size-specific cart selection',async()=>{
 const {window,document}=parseHTML(fs.readFileSync(new URL('../dist/index.html',import.meta.url),'utf8'));
 const memory=new Map();globalThis.window=window;globalThis.document=document;globalThis.localStorage={getItem:k=>memory.get(k)??null,setItem:(k,v)=>memory.set(k,v)};globalThis.location=new URL('https://test.local/');
 window.DALLASSS_CONFIG={mode:'demo',assetBase:'./assets/',bundleDiscountPercent:0};
 for(const select of document.querySelectorAll('select')){Object.defineProperty(select,'value',{configurable:true,get(){return this.querySelector('option[selected]')?.value??this.querySelector('option')?.value??'';},set(v){for(const o of this.querySelectorAll('option')){if(o.value===v)o.setAttribute('selected','');else o.removeAttribute('selected');}}});}
 window.HTMLElement.prototype.scrollIntoView=function(){};
 await import('../dist/assets/app.mjs?domtest');
 assert.equal(document.querySelectorAll('.product-card').length,4);
 document.querySelector('[data-favorite="1"]').click();assert.equal(document.getElementById('favorite-count').textContent,'۱');
 document.querySelector('[data-action="favorites"]').click();assert.equal(document.querySelectorAll('.product-card').length,1);
 document.querySelector('[data-open-product="1"]').click();assert.ok(document.getElementById('product-dialog').hasAttribute('open'));
 document.querySelector('[data-size="L"]').click();document.querySelector('[data-action="add-current"]').click();
 assert.equal(document.getElementById('cart-count').textContent,'۱');
 document.querySelector('[data-action="cart"]').click();assert.ok(document.querySelector('#cart-lines').textContent.includes('L'));
 document.querySelector('[data-action="checkout"]').click();assert.ok(document.getElementById('info-content').textContent.includes('پرداختی ثبت نشده'));
});

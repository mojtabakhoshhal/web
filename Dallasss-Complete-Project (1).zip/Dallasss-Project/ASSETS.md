# Asset sources

Preview catalog imagery is illustrative and is not a claim that the photographed garments are listed by Basalam, Vegas, Verna or Shopino.

Unsplash photo identifiers: hero `1488161628813-04466f872be2`; jacket `1551028719-00167b16eac5`; hoodie `1556821840-3a63f95609a7`; shirt `1598033129183-c4f50c736f10`; denim `1542272604-787c3835535d`; sneaker `1549298916-b41d501d3772`; coat `1544022613-e87ca75a784a`; t-shirt `1521572163474-6864f9cf17ab`; editorial `1512436991641-6745cdb1723f`. URLs use https://images.unsplash.com/photo- followed by the identifier. License: https://unsplash.com/license .

Vazirmatn variable font v33.003 by the Vazirmatn project: https://github.com/rastikerdar/vazirmatn . SIL Open Font License: https://github.com/rastikerdar/vazirmatn/blob/master/OFL.txt .

The WordPress package includes only the hero/editorial design photos; illustrative product JPEGs are excluded. Live product photography is remote media on approved supplier CDNs.

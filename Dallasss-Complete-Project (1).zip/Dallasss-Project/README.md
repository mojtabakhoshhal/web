# DALLASSS

Persian luxury menswear storefront preview and portable WordPress integration source.

The storefront runs from `dist/index.html` without a server build. CSS is generated with `npm run build:css`. Run `npm test` for frontend behavior and `npm run check:php` for PHP 8.2 syntax parsing. Python behavior tests live in `integration-kit/tests`.

Run `python scripts/package-deliverables.py` after frontend or integration changes. It copies the exact storefront source into the WordPress plugin, omits illustrative product JPEGs, emits the reference database DDL, and regenerates installable ZIPs and the Persian implementation page.

Source of truth for setup, operational boundaries, incomplete account integrations and the six-step shared-host migration: `integration-kit/README.fa.md` and `integration-kit/ARCHITECTURE.md`.

Retail policy: source price ×1.35, no extra pricing buffer, upward rounding only for fractional Tomans, shipping configured separately, no default bundle discount.
